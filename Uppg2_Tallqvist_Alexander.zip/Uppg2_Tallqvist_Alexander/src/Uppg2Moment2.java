import static javax.swing.JOptionPane.*;
import java.time.YearMonth;

public class Uppg2Moment2 {
	
	public static void main (String[] args) {
		
		int year, month, daysInMonth;
		YearMonth yearMonth;
		
		year  = Integer.parseInt(showInputDialog("Ange ett �rtal:"));
		month = Integer.parseInt(showInputDialog("Ange en m�nad:"));

		yearMonth   = YearMonth.of(year, month);
		daysInMonth = yearMonth.lengthOfMonth();
		
		showMessageDialog(null, daysInMonth);
	}
}

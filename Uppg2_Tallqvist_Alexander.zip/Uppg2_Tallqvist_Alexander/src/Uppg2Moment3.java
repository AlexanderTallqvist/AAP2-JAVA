import static javax.swing.JOptionPane.*;

public class Uppg2Moment3 {
	
	public static void main (String[] args) {
		
		double number;
		String out;
		
		number = Double.parseDouble(showInputDialog("Ange ett tal:"));
		
		if(number % 1 == 0) {
			out = "Talet " + number + " �r ett heltal";
		} else {
			out = "Talet " + number + " �r inte ett heltal";
		}
		
		showMessageDialog(null, out);
	}
}

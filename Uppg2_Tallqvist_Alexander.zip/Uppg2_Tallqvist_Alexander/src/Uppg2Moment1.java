import static javax.swing.JOptionPane.*;

public class Uppg2Moment1 {
	
	public static void main (String[] args) {
		
		String out;
		int year;
		
		year = Integer.parseInt(showInputDialog("Ange ett �rtal:"));
		
		if(year % 400 == 0 || ((year % 4 == 0) && (year % 100 != 0))) {
			out = "�ret " + year + " �r ett skott�r";
		} else {
			out = "�ret " + year + " �r inte ett skott�r";
		}
		
		showMessageDialog(null, out);
	}
}

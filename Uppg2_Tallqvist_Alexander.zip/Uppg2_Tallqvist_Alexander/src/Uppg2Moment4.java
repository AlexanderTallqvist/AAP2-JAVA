import java.io.*;

public class Uppg2Moment4 {
	
	public static void main (String[] args) throws IOException {
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));	
		
		String input, output = "";
		int number;
		
		System.out.print("Ange ett heltal: ");
		
		input  = reader.readLine();
		number = Integer.parseInt(input);
		
		for(int i = 1; i <= 10; i++) {
			output += i + " * " + number + " = " + (i  *number) + "\n";
		}
		
		System.out.print(output);
	}
}

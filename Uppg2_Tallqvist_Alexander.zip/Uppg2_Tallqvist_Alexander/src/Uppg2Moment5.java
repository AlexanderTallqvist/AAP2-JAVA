import static javax.swing.JOptionPane.*;

public class Uppg2Moment5 {
	
	public static void main (String[] args) {
		
		
		String output = "";
		int number;
		
		number = Integer.parseInt(showInputDialog("Ange ett heltal: "));
		
		for(int i = 1; i <= 10; i++) {
			output += i + " * " + number + " = " + (i  *number) + "\n";
		}
		
		showMessageDialog(null, output);
	}
}

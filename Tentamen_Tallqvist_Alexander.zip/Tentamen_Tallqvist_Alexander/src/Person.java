

public abstract class Person {
	
	public String name;
	
	public String id;
	
	public String getName() {
		return this.name;
	}
	
	public String getId() {
		return this.id;
	}
	
	public String getInfo() {
		return this.getName() + " " + this.getId();
	}
}

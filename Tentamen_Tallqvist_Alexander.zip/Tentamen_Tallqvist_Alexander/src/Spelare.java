import java.util.ArrayList;
import java.util.Random;

public class Spelare extends Person {
	
	private ArrayList<SpelKort> inPlay = new ArrayList<SpelKort>();
	
	private ArrayList<SpelKort> notInPlay  = new ArrayList<SpelKort>();
	
	private Djur animal;
	
	private boolean isPlaying = true;
	
	private int turn;

	Spelare(String name, Djur animal, int turn) {
		this.name   = name;
		this.animal = animal;
		this.turn   = turn;
		this.id     = this.generateId();
	}
	
	// Constructor when reading from save fil
	Spelare(String name, Djur animal, int turn, String id) {
		this.name   = name;
		this.animal = animal;
		this.turn   = turn;
		this.id     = id;
	}
	
	// Call the players animal noise
	public String makeAnimalNoise() {
		return this.animal.getSound();
	}
	
	
	// Get general information about the player
	public String getPlayerInformation() {
		String returnString, playedCards = "", handCards = "";
		
		for(int i = 0; i < this.inPlay.size(); i++) {
			playedCards += this.inPlay.get(i).getColor() + "-" + this.inPlay.get(i).getValue() + ", ";
		}
		
		for(int j = 0; j < this.notInPlay.size(); j++) {
			handCards += this.notInPlay.get(j).getColor() + "-" + this.notInPlay.get(j).getValue() + ", ";
		}
		
		returnString  = "Spelarens namn: " + this.getName() + "\n";
		returnString += "Spelarens l�te: " + this.makeAnimalNoise() + "\n";
		returnString += "Spelade kort: "   + playedCards + "\n";
		returnString += "Kort i handen: "  + handCards + "\n";
		
		return returnString;
	}
	
	public String generateSaveString() {
		String returnString, playedCards = "", handCards = "";
		
		for(int i = 0; i < this.inPlay.size(); i++) {
			playedCards += this.inPlay.get(i).getColor() + "-" + this.inPlay.get(i).getValue() + ",";
		}
		
		for(int j = 0; j < this.notInPlay.size(); j++) {
			handCards += this.notInPlay.get(j).getColor() + "-" + this.notInPlay.get(j).getValue() + ",";
		}
		
		returnString  = this.getName() + ",";
		returnString += this.getId() + ",";
		returnString += this.getTurn() + ",";
		returnString += this.getAnimal().getName() + ",";
		returnString += this.getAnimal().getSound() + "#";
		returnString += playedCards + "&";
		returnString += handCards + "\n";
		
		return returnString;	
	}
	
	
	// Generate random userID
	private String generateId() {
		Random random = new Random();
		String userId = "";
		
		String part1  = String.valueOf(random.nextLong()).substring(1, 7);
		String part2  = String.valueOf(random.nextLong()).substring(1, 5);
		userId = part1 + "-" + part2;
		
		return userId;
	}
	
	
	// Add new cards to hand
	public void addNewCardToHand(SpelKort card) {
		this.notInPlay.add(card);
	}
	
	// Add new cards to table stack
	public void addNewCardToTable(SpelKort card) {
		this.inPlay.add(card);
	}
	
	
	// Getters and Setters
	public ArrayList<SpelKort> getInPlay() {
		return inPlay;
	}

	public void setInPlay(ArrayList<SpelKort> inPlay) {
		this.inPlay = inPlay;
	}

	public ArrayList<SpelKort> getNotInPlay() {
		return notInPlay;
	}

	public void setNotInPlay(ArrayList<SpelKort> notInPlay) {
		this.notInPlay = notInPlay;
	}

	public Djur getAnimal() {
		return animal;
	}

	public void setAnimal(Djur animal) {
		this.animal = animal;
	}

	public boolean isPlaying() {
		return isPlaying;
	}

	public void setPlaying(boolean isPlaying) {
		this.isPlaying = isPlaying;
	}

	public int getTurn() {
		return turn;
	}

	public void setTurn(int turn) {
		this.turn = turn;
	}
	
}

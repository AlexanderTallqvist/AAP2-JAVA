

public interface SpelKortInterface {

	public final String[]colors = {"hj�rter", "spader", "ruter", "kl�ver"};
	
	public final String[]values = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J" ,"Q", "K"};
	
	String getColor();
	
	String getValue();
	
	String getInfo();
}

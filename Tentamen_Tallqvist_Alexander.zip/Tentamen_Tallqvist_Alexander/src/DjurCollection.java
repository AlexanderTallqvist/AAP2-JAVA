import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class DjurCollection {

	public  ArrayList<Djur> animalCollection = new ArrayList<Djur>();
	
	public  int numberOfAnimals;
	
	DjurCollection() {
		this.createAnimalList();
	}
	
	
	// Create a new animalCollection from a text file
	public void createAnimalList() {
		
		try {	
			Scanner in = new Scanner(new FileReader("src/TextFiles/animals.txt"));
			
			while (in.hasNextInt()) {
				this.numberOfAnimals = in.nextInt();	
			}

			while (in.hasNextLine()) {
				String[]animalNameAndSound = in.nextLine().split(",");
				
				if(animalNameAndSound.length == 2) {
					String name  = animalNameAndSound[0].toLowerCase();
					String sound = animalNameAndSound[1].toLowerCase();
					
					if(this.checkIfAnimalExists(name, sound)) {
						this.animalCollection.add(new Djur(name, sound));	
					}
				}
			}
			
			in.close();
		} catch (Exception e) {
			System.out.println("Djurfilen kunde inte l�sas in");
		}
	}
	
	
	// Check if the animal already exists in the animalCollection
	public boolean checkIfAnimalExists(String animalName, String animalSound) {
		
		for(int i = 0; i < this.animalCollection.size(); i++) {
			String currentName  = this.animalCollection.get(i).getName();
			String currentSound = this.animalCollection.get(i).getSound();
			
			if(currentName.equals(animalName) && currentSound.equals(animalSound)) {
				return false;
			}
		}
		
		return true;
	}
	
	
	// Add a new animal by user input
	public boolean addNewAnimal() {
		
		String message = "Ange ett nyt djur i f�ljande format: Namn,L�te\nExempel: Hund,Woff";
		
		try {
			String[]animalNameAndSound = JOptionPane.showInputDialog(message).split(",");
			
			if(animalNameAndSound.length == 2) {
				
				String name  = animalNameAndSound[0].toLowerCase();
				String sound = animalNameAndSound[1].toLowerCase();
				
				if(checkIfAnimalExists(name, sound)) {
					this.animalCollection.add(new Djur(name, sound));
					this.numberOfAnimals+= 1;
					JOptionPane.showMessageDialog(null, "Djuret har lagts till i listan.");
					return true;
				} else {
					JOptionPane.showMessageDialog(null, "Djuret finns reda i spelet. F�rs�k med ett annat.");	
				}
				
			} 	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Djuret kunde inte l�ggas till.");
		}
		
		return false;
	}
}

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Utilities {

	// Save to a file
	public static void saveToFile(String message, String fileName) {

		String outString = message;

		try {
			PrintWriter out = new PrintWriter(new FileOutputStream(new File("src/TextFiles/" + fileName), true));
			out.append(outString);
			out.close();

		} catch (FileNotFoundException e) {
			System.out.print("Det gick inte att spara till filen " + fileName);
		}
	}

	
	// Clear a file
	public static void clearFile(String fileName) {
		PrintWriter writer;
		try {
			writer = new PrintWriter("src/TextFiles/" + fileName);
			writer.print("");
			writer.close();
		} catch (FileNotFoundException e) {
			System.out.print("Filen "  + fileName + " hittades inte");
		}
	}
	
	// Read a file
	public static ArrayList<String> readFile(String fileName) {
		ArrayList<String> fileData = new ArrayList<String>();

		try {
			Scanner in = new Scanner(new FileReader("src/TextFiles/" + fileName));
			while (in.hasNextLine()) {
				fileData.add(in.nextLine());
			}

			in.close();
			return fileData;

		} catch (FileNotFoundException e) {
			System.out.println("Det gick inte att l�sa int filen " + fileName);
		}

		return fileData;
	}
	
	// Read in the players from the save file
	public static ArrayList<Spelare> readSaveFromFile() {
		
		ArrayList<Spelare> allPlayers = new ArrayList<Spelare>();
		ArrayList<String> objectStrings = Utilities.readFile("saveFile.txt");
		DjurCollection animals = new DjurCollection();
		Collections.shuffle(animals.animalCollection);
		
		if(!objectStrings.isEmpty()) {

			try {
				
				for(int i = 0; i < objectStrings.size(); i++) {
					
					String playerString = objectStrings.get(i);
					String[]playerInfoAndCards = playerString.split("#");

					String[]playerInfo  = playerInfoAndCards[0].split(",");
					String[]playerCards = playerInfoAndCards[1].split("&");

					
					// The players general information
					String playerName  = playerInfo[0];
					String playerId    = playerInfo[1];
					int    playerTurn  = Integer.parseInt(playerInfo[2]);
					
					// Find the players animal
					String playerAnimalName  = playerInfo[3];
					String playerAnimalSound = playerInfo[4];
					Djur   playerAnimal      = null;
					
					animalLoop:
					for(int j = 0; j < animals.animalCollection.size(); j++) {
						if(animals.animalCollection.get(j).getName().equals(playerAnimalName) 
						&& animals.animalCollection.get(j).getSound().equals(playerAnimalSound)) {
							playerAnimal = animals.animalCollection.get(j);
							break animalLoop;
						}
					}
					
					// Re-create the player
					allPlayers.add(new Spelare(playerName, playerAnimal, playerTurn, playerId));
					
					// Add the players cards back to the players
					String[]cardsOnTable = playerCards[0].split(",");
					String[]cardsInHand  = playerCards[1].split(",");
					
					
					// Add back the cards that the player has played
					for(int k = 0; k < cardsOnTable.length; k++) {
						String[] colorAndValue = cardsOnTable[k].split("-");
						
						if(colorAndValue.length == 2) {
							SpelKort newCard = new SpelKort(colorAndValue[0], colorAndValue[1]);
							allPlayers.get(i).addNewCardToTable(newCard);
							
						}
					}
					
					// Add back the cards that the player had in his/her hand
					for(int l = 0; l < cardsInHand.length; l++) {
						String[] colorAndValue = cardsInHand[l].split("-");
						
						if(colorAndValue.length == 2) {
							SpelKort newCard = new SpelKort(colorAndValue[0], colorAndValue[1]);
							allPlayers.get(i).addNewCardToHand(newCard);
						}
					}
				}
			}
			
			catch (Exception e) { 
				e.printStackTrace();
				System.out.println("Det gick inte att l�sa int filen saveFile.txt");
			}
		}
		
		
		return allPlayers;
	}
}

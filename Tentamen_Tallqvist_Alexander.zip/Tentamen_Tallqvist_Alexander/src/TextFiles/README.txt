Alla moment utf�rda.

L�ser in djuren fr�n animals.txt i b�rjan av programmet, och anv�nder mig av DjurCollection.createAnimalList och Djur constructorn.
Om det finns mindre djur �n vad det finns spelare, s� ber jag anv�ndaren mata in nya djur och sparar dem i animals.txt

Skapar Spelarena med anv�ndar input och Spelare constructorn. Vid situationer d�r spelarna l�ses in fr�n saveFile.txt, anv�nds
Spelar constructorn som f�rutom namn, djur, och turn, ocks� tar in spelarens ID som parameter.

Spelkorten skapas med hj�lp av v�rdena i SpelkortInterface, och delas ut �t spelarna med distributeCards().
Korten blandas i slutet av createDeck metoden, med hj�lp av Collections.shuffle.
Utilities.readSaveFromFile() delar ut spelarnas gamla kort d� saveFile.txt l�ses in.

playTheGame metoden startar spelet n�r alla v�rden som beh�vs �r inmatade av anv�ndaren, eller inl�sta fr�n saveFile.txt

Har valt att anv�nda ArrayLists f�r hanteringen av datan, pga att de �r mer flexibla �n vanliga arrays (storleken g�r t.ex. att �ndras vid behov).
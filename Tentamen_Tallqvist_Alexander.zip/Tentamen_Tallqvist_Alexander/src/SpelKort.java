
public class SpelKort implements SpelKortInterface {
	
	private String color;
	
	private String value;
	
	SpelKort(String color, String value) {
		this.color = color;
		this.value = value;
	}

	public String getColor() {
		return this.color;
	}

	public String getValue() {
		return this.value;
	}

	public String getInfo() {
		return this.getValue() + "-" + this.getColor();
	}

}

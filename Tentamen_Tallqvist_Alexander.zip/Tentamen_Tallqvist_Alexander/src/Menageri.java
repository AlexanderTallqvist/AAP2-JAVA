import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showOptionDialog;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import javax.swing.JFrame;

public class Menageri {
	
	public static void main(String[] args) { 
		
		// Variables
		DjurCollection allAnimals = null;
		ArrayList<SpelKort> allCards = createDeck();
		ArrayList<Spelare> allPlayers;
		String userInput;
		int userChoise;
		boolean keepGoing = true;
		
		// Message box
		JFrame frame = new JFrame();
		String[] options = new String[2];
		options[0] = new String("Nytt spel");
		options[1] = new String("Ladda spel");
		
		// Clear the log file
		Utilities.clearFile("log.txt");
		
		userChoise = showOptionDialog(frame.getContentPane(), "Vad vill du g�ra?", "Menageri", 0, INFORMATION_MESSAGE, null, options, null);
		
		// Start a new game
		if(userChoise == 0) {
			while (keepGoing == true) {
				try {
					userInput  = showInputDialog(null, "Ange m�ngden spelare. (Mellan 4-10)", "Spelare", QUESTION_MESSAGE);
					int amount = Integer.parseInt(userInput); 
					
					if(amount > 3 && amount < 11) {
						
						// Make sure the we have enough animals
						allAnimals = addNewAnimals(amount);
						
						// Add the new players
						allPlayers = addNewPlayers(amount, allAnimals);
						
						// Distribute the cards to the players
						allPlayers = distributeCards(allPlayers, allCards);
						
						// Play the game
						keepGoing = playTheGame(allPlayers, amount);
						
					} else {
						throw new Exception();
					}
					
				} catch (Exception e) {
					showMessageDialog(null, "Fel v�rde. Ange ett tal mellan 4-10.");
				}
			}	
		}
		
		// Load from save
		if(userChoise == 1) {
			while (keepGoing == true) {
				allPlayers = Utilities.readSaveFromFile();
				keepGoing = playTheGame(allPlayers, allPlayers.size());
			}
		}
	}
	
	
	// Create the card deck at the start of the game
	public static ArrayList<SpelKort> createDeck() {
		ArrayList<SpelKort> cards = new ArrayList<SpelKort>();
		
		for(int i = 0; i < SpelKortInterface.colors.length; i++) {
			for(int j = 0; j < SpelKortInterface.values.length; j++) {
				cards.add(new SpelKort(SpelKortInterface.colors[i], SpelKortInterface.values[j]));
			}
		}
		// Shuffle the cards
		Collections.shuffle(cards);
		return cards;
	}
	
	
	// Create new players at the start of the game
	public static ArrayList<Spelare> addNewPlayers(int amount, DjurCollection animals) {
		
		ArrayList<Spelare> players = new ArrayList<Spelare>();
		String message = "Ange nya spelare i f�ljande format: NamnEtt,NamnTva,NamnTre... \nExempel: Alexander,Henrik,Maria";
		int amountOfPlayers = amount;
		int playerIndex = 0;
		boolean keepGoing = true;
		
		// Create the players
		while(keepGoing) {
			try {
				String[]userInput = showInputDialog(null, message, "Ny Spelare", QUESTION_MESSAGE).split(",");
				
				if(userInput.length == amountOfPlayers) {
					
					while(amountOfPlayers > 0) {
						String playerName = userInput[playerIndex];
						Djur playerAnimal = animals.animalCollection.get(playerIndex);
						players.add(new Spelare(playerName, playerAnimal, playerIndex));
						playerIndex ++;
						amountOfPlayers--;
					}
					keepGoing = false;
					
				} else {
					throw new Exception();
				}
				
			} catch (Exception e) {
				showMessageDialog(null, "Fel v�rden. Du m�sta ha " + amount + " st. spelare.");
			}
		}
		
		return players;
	}
	
	
	// Create the animalCollection, and add new ones if needed
	public static DjurCollection addNewAnimals(int amount) {
		DjurCollection animals = new DjurCollection();
		
		int amountOfPlayers = amount;
		int amountOfAnimals = animals.animalCollection.size();
		
		if(amountOfAnimals < amountOfPlayers) {
			while (amountOfAnimals < amountOfPlayers) {
				if(animals.addNewAnimal()) {
					amountOfPlayers--;		
				}
			}
			
			// Save all the animals to the the animals file
			Utilities.clearFile("animals.txt");
			int animalAmount = animals.animalCollection.size();
			String animlSaveString = animalAmount + "\n";
			
			for(int i = 0; i < animalAmount; i++) {
				Djur currentAnimal =  animals.animalCollection.get(i);
				animlSaveString  += currentAnimal.getSaveString();
			}
			
			Utilities.saveToFile(animlSaveString, "animals.txt");
		}
		
		
		//Shuffle the animals
		Collections.shuffle(animals.animalCollection);
		return animals;
	}
	
	
	// Distribute all the cards to the players
	public static ArrayList<Spelare> distributeCards(ArrayList<Spelare> players, ArrayList<SpelKort> cards) {
		
		int playerAmount = players.size();
		int targetIndex  = 0;
		
		for(int i = 0; i < cards.size(); i++) {
			players.get(targetIndex).addNewCardToHand(cards.get(i));
			targetIndex ++;
			
			if(targetIndex == playerAmount) {
				targetIndex = 0;
			}
		}
		
		return players;
	}
	
	
	// Play the game
	public static boolean playTheGame(ArrayList<Spelare> players, int amount) {
		
		// Variables
		boolean keepPlaying = true;
		int playerAmount = amount;
		int turnIndex = 0;
		int userInput;
		int roundCount = 0;
		ArrayList<Spelare> allPlayers = players;
		SpelKort lastCard, currentCard;
		Spelare lastPlayer, currentPlayer;
		String logMessage, roundMessage;
		
		// Message box
		JFrame frame = new JFrame();
		String[] options = new String[2];
		options[0] = new String("Ny round");
		options[1] = new String("Spara och st�ng");
		
		
		while(keepPlaying) {
			userInput = showOptionDialog(frame.getContentPane(), "Vad vill du g�ra?", "Menageri", 0, INFORMATION_MESSAGE, null, options, null);
			
			// Continue
			if(userInput == 0) {
				
				// Reset lastCard, lastPlayer and turnIndex each round
				lastCard   = null;
				lastPlayer = null;
				turnIndex  = 0;
				roundCount++;
				
				//Add the round count to the log file
				roundMessage = "========= ROUND " + roundCount + " =========\n";
				System.out.println(roundMessage);
				Utilities.saveToFile(roundMessage, "log.txt");
				
				// Play a round
				while(turnIndex < playerAmount) {
					
					currentPlayer = allPlayers.get(turnIndex);
					
					if(currentPlayer.isPlaying()) {
						currentCard = currentPlayer.getNotInPlay().get(0);
						
						// Move the card around for the player
						currentPlayer.getNotInPlay().remove(0);
						currentPlayer.getInPlay().add(currentCard);
						
						// Log the message
						logMessage = "";
						logMessage = currentPlayer.getId() + "," + currentCard.getInfo() + "\n";
						Utilities.saveToFile(logMessage, "log.txt");
						
						// Print out a status message
						System.out.println(currentPlayer.getPlayerInformation());
						
						
						if(lastCard != null) {
							
							// Check if the numbers on the two last cards are a match
							if(lastCard.getValue().equals(currentCard.getValue())) {
								
								String message = "";
								
								// Generate random outcome
								Random rand = new Random();
								int x = rand.nextInt(2);
								
								// Current player won round
								if(x == 0) {
									message  = currentPlayer.getId() + "," + currentPlayer.makeAnimalNoise() + "\n";
									message += lastPlayer.getId() + "," + lastPlayer.makeAnimalNoise() + "\n";
									
									// Move the losers card pile to the winner
									ArrayList<SpelKort> winnerCards = lastPlayer.getInPlay();
									Collections.reverse(Arrays.asList(winnerCards));
									currentPlayer.getNotInPlay().addAll(winnerCards);
									lastPlayer.getInPlay().clear();
								} 
								
								// The last player won the round
								else {
									message  = lastPlayer.getId() + "," + lastPlayer.makeAnimalNoise() + "\n";
									message += currentPlayer.getId() + "," + currentPlayer.makeAnimalNoise() + "\n";
									
									// Move the losers card pile to the winner
									ArrayList<SpelKort> winnerCards = currentPlayer.getInPlay();
									Collections.reverse(Arrays.asList(winnerCards));
									lastPlayer.getNotInPlay().addAll(winnerCards);
									currentPlayer.getInPlay().clear();
								}
								Utilities.saveToFile(message, "log.txt");
								System.out.println(message);
							}
						}
						
						// Set the lastPlayer and the lastCard
						lastPlayer = currentPlayer;
						lastCard   = currentCard;
					} 
					
					// Remove a player if they have no cards left in their hand
					if(currentPlayer.getNotInPlay().size() == 0) { 
						allPlayers.remove(currentPlayer);
						currentPlayer.setPlaying(false);
						String message = currentPlayer.getName() + ", " + currentPlayer.getId() + " faller ut ur spelet.\n";
						Utilities.saveToFile(message, "log.txt");
						System.out.println(message);
						playerAmount-= 1;
						turnIndex-= 1;
						
						// Reset last card an player if the current player is removed
						lastPlayer = null;
						lastCard   = null;
						
						// Check if we have a winner
						if(allPlayers.size() == 1) {
							String winner = "Winner: " + allPlayers.get(0).getInfo();
							showMessageDialog(null, winner);
							Utilities.saveToFile(winner, "log.txt");
							keepPlaying = false;
							break;
						}
					}
					
					turnIndex++;
				}
				
			}
			
			// Save and exit
			if(userInput == 1) {
				
				Utilities.clearFile("saveFile.txt");
				
				for(int i = 0; i < allPlayers.size(); i++) {
					Utilities.saveToFile(allPlayers.get(i).generateSaveString(), "saveFile.txt");
				}
				
				showMessageDialog(null, "Spelet sparas och st�ngs.");
				keepPlaying = false;
			}
		}
		
		return false;
	}
	
}


























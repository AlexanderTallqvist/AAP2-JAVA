
public class Djur {

	
	private String name;
	
	private String sound;
	
	
	Djur(String name, String sound) {
		this.name  = name;
		this.sound = sound;	
	}
	
	// Get information about the animal
	public String information() {
		return this.getName() + " - " + this.getSound();
	}
	
	// Get the animal save string
	public String getSaveString() {
		return this.getName() + "," + this.getSound() + "\n";
	}
	
	// Getters
	public String getName() {
		return this.name;
	}
	
	public String getSound() {
		return this.sound;
	}
}

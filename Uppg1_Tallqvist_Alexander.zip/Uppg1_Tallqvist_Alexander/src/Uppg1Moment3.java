import javax.swing.JOptionPane;

public class Uppg1Moment3 {
	
	public static void main(String[] args) {
		
		int vikt, langd;
		double bmi, mlangd;
		
		vikt  = Integer.parseInt(JOptionPane.showInputDialog("Ange vikt i KG:"));
		langd = Integer.parseInt(JOptionPane.showInputDialog("Ange l�ngd i cm:"));
		
		mlangd = langd / 100.0;
		bmi = Math.round(vikt / (mlangd * mlangd) * 10d) / 10d; 
		
        outputBMI(bmi);
	}

    public static void outputBMI(double bmi) {
    	
    	String out;
    	out = "Din BMI �r: " + bmi + "\nViktklass: ";

        if(bmi < 18.5) {
        	out += "Undervikt.";
        }else if (bmi < 25) {
        	out += "Normalvikt.";
        }else if (bmi < 30) {
        	out += "�vervikt.";
        }else {
        	out += "Fetma.";
        }
        
        JOptionPane.showMessageDialog(null, out);
    }
}

import javax.swing.JOptionPane;

public class Uppg1Moment2 {
	public static void main (String[] args) {
		
		String in, out;
		double diameter, area, omkrets, radie;
		
		in  = JOptionPane.showInputDialog("Ange circkelns diameter:");
		
		diameter = Double.parseDouble(in);
		radie    = diameter / 2;
		
		area    = Math.round(Math.PI * (radie * radie) * 100.0) / 100.0;
		omkrets = Math.round((Math.PI * 2) * radie * 100.0) / 100.0;
		
		out = "Arean �r: " + area + " enheter^2" + 
		"\nOmkretsen �r: " + omkrets + " enheter";

		JOptionPane.showMessageDialog(null, out);
	}
}

import javax.swing.JOptionPane;
public class Uppg1Moment1 {

	public static void main (String[] args) {
		
		String in, out;
		
		in  = JOptionPane.showInputDialog("Ange namn:");
		out =  "Hej " + in;
		
		JOptionPane.showMessageDialog(null, out);
	}
}

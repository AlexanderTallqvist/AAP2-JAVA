import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Uppg5Moment1 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		String userInput;
		StringHandler myStringHandler = new StringHandler();

		while (validInput == true) {

			try {
				userInput = showInputDialog(null, "Ange en str�ng.", "Str�ng", QUESTION_MESSAGE);
				
				if(userInput.length() == 0) {
					throw new Exception();
				} else {
					myStringHandler.setString(userInput);
					myStringHandler.increaseStringCount();
				}
				
			} catch (Exception e) {
				validInput = false;
				utskrift(myStringHandler);
			}
		}
	}
	
	public static void utskrift(StringHandler myStringHandler) {
		String message = "Du har givit " + myStringHandler.getStringCount() + " str�ng(ar). \nDen senaste str�ngen var: "
			   + myStringHandler.getString() + ", och den hade " + myStringHandler.getWords() + " ord.";
		
		showMessageDialog(null, message);	
	}
}

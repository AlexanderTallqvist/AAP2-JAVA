
public class StringHandler {

	private String str;
	static int stringCount = 0;

	StringHandler() {
	}

	StringHandler(String s) {
		str = s;
	}

	int getWords() {
		if(this.getString() != null) {
			String[] temp = this.str.split(" ");
			int i = temp.length;
			return i;
		} else {
			return 0;
		}
	}

	String getString() {
		return this.str;
	}

	void setString(String str) {
		this.str = str;
	}

	void increaseStringCount() {
		StringHandler.stringCount += 1;
	}

	int getStringCount() {
		return StringHandler.stringCount;
	}
	
	String occuranceCount(String type, String message) {
		int lastIndex = 0;
		int amount = 0;

		while (lastIndex != -1) {

		    lastIndex = this.getString().indexOf(message, lastIndex);

		    if (lastIndex != -1) {
		    	amount++;
		        lastIndex += message.length();
		    }
		}
		
		if("T".equals(type)) {
			return amount + " antal symboler " + "\"" + message + "\"";		
		}
		
		if("S".equals(type)) {
			return amount + " antal str�ngar " + "\"" + message + "\"";		
		}
		else
			return " - Ingra tr�ffar. Ogiltig analysmetod - ";
	}
	

}
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.util.ArrayList;
import java.util.List;

public class Uppg5Moment3 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		String userInput;
		StringHandler myStringHandler = new StringHandler();
		List<StringHandler> objectArray = new ArrayList<StringHandler>();

		while (validInput == true) {

			try {
				userInput = showInputDialog(null, "Ange en str�ng.", "Str�ng", QUESTION_MESSAGE);
				
				if(userInput.length() == 0) {
					throw new Exception();
				} else {
					myStringHandler.setString(userInput);
					myStringHandler.increaseStringCount();
					objectArray.add(myStringHandler);
				}
				
			} catch (Exception e) {
				validInput = false;
				utskrift(objectArray, myStringHandler);
			}
		}
	}
	
	public static void utskrift(List<StringHandler> objectArray, StringHandler myStringHandler) {
		String message = "Du tryckte cancel. De senaste " + myStringHandler.getStringCount() + " str�ngar du givit var:\n";
		
		for(int i = objectArray.size(); i > 0; i--) {
			message += "\"" + objectArray.get(i - 1).getString() + "\" har " + objectArray.get(i - 1).getWords() + " ord.\n"; 
		}
		
		showMessageDialog(null, message);	
	}
}

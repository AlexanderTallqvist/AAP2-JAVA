import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.util.ArrayList;
import java.util.List;

// Bygger p� moment2, eftersom att jag var os�ker om jag l�st moment3 r�tt.

public class Uppg5Moment4 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		StringHandler myStringHandler = null;
		List<StringHandler> objectArray = new ArrayList<StringHandler>();
		String analyzeMessag;
		String analyzeType;
		String analyzeString;
		
		while (validInput == true) {

			try {
				myStringHandler = new StringHandler(showInputDialog(null, "Ange en str�ng.", "Str�ng", QUESTION_MESSAGE));
				
				if(myStringHandler.getString().length() == 0) {
					throw new Exception();
				} else {
					objectArray.add(myStringHandler);
					myStringHandler.increaseStringCount();
				}
				
			} catch (Exception e) {
				validInput = false;
				analyzeMessag = showInputDialog(null, "Vill du analysera dina str�ngar: Skriv Y/N.", "Analys", QUESTION_MESSAGE);
				
				if("Y".equals(analyzeMessag)) {
					analyzeType = showInputDialog(null, "Vill du analysera tecken eller str�ngar: Skriv T/S.", "Analysr", QUESTION_MESSAGE);
					analyzeString = showInputDialog(null, "Ange tecknet eller str�nger du vill analysera.", "Analys", QUESTION_MESSAGE);
					analysUtskrift(objectArray, myStringHandler, analyzeType, analyzeString);
				} else {
					utskrift(objectArray, myStringHandler);
				}
				
			}
		}
	}
	
	public static void utskrift(List<StringHandler> objectArray, StringHandler myStringHandler) {
		String message = "Du tryckte cancel. De senaste " 
				   	   + myStringHandler.getStringCount()
			           + " str�ngar du givit var:\n";

		for (int i = objectArray.size(); i > 0; i--) {
			message += "\"" + objectArray.get(i - 1).getString() + "\" har " + objectArray.get(i - 1).getWords() + " ord.\n";
		}

		showMessageDialog(null, message);
	}

	public static void analysUtskrift(List<StringHandler> objectArray, StringHandler myStringHandler, String analyzeType, String analyzeString) {
		String message = "Du tryckte cancel. De senaste " 
					   + myStringHandler.getStringCount()
				       + " str�ngar du givit var:\n";

		for (int i = objectArray.size(); i > 0; i--) {
			message += "Str�ngen \"" + objectArray.get(i - 1).getString() + "\" som har "
					+ objectArray.get(i - 1).occuranceCount(analyzeType, analyzeString) + ".\n";
		}

		showMessageDialog(null, message);
	}
	
	
	
	
}

import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.util.Arrays;
import java.util.stream.IntStream;


public class Uppg3Moment2 {
	
  public static void main(String[] args) {
	  
	  String userInput;
	  String[] validInputs = {"<", ">", "="};
	  int[] computerGuessArray = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	  int guess, guessAmount = 0;
	  boolean validInput = false;
	  
	    while (validInput == false) {
	        
	  	  try {
	  		
	  		guess = computerGuessArray[computerGuessArray.length/2];
	  	    userInput = showInputDialog(null, "Datorn gissade: " + guess +  ". Ange >, < eller =", "Fr�ga", QUESTION_MESSAGE);
	  	    
	  	    if(Arrays.asList(validInputs).contains(userInput)) {
	  	    	
	  	    	guessAmount++;
	  	    	computerGuessArray = compareResults(userInput, computerGuessArray, guess);
		  	    
		  	    if(computerGuessArray == null) {
		  	    	showMessageDialog(null, "Det tog " + guessAmount + " f�rs�k f�r datorn att gissa dit tal.");
		  	    	validInput = true;
		  	    }
		  	    
	  	    } else {
	  	    	throw new Exception();
	  	    }
	  	    
	  	  }
	  	  catch (Exception e){
	  	    showMessageDialog(null, "N�gonting gick fel! F�ljer du instruktionerna?");
	  	    return;
	  	  }
      }
  }
  
  
  public static int[] compareResults(String input, int computerGuessArray[], int guess) {
	  
      switch(input) {
      
      	case ">": 
      		return computerGuessArray = IntStream.rangeClosed(guess + 1, computerGuessArray[computerGuessArray.length - 1]).toArray();
      		
      	case "<":
      		return computerGuessArray = IntStream.rangeClosed(computerGuessArray[0], guess - 1).toArray();
      		
      	default :
      		return null;
      }
    		  
  }
}

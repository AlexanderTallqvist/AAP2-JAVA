import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Uppg3Moment1 {
	
  public static void main(String[] args) {
	  
    String userInput;
    
    boolean validInput = false;
    boolean checkResult;
    
    int computerInt = (int)(Math.random() * 10 + 1);
    int userInt, guessAmount = 0;

    while (validInput == false) {
    	
      guessAmount++;
      
	  try {
	    userInput = showInputDialog(null, "Gissa ett heltal mellan 1-10?", "Fr�ga", QUESTION_MESSAGE); 
	    userInt   = Integer.parseInt(userInput);
	    
	    checkResult = compareIntegers(userInt, computerInt, guessAmount);
	    if(checkResult == true) {
	    	validInput = true;	
	    }
	  }
	  catch (NumberFormatException e){
	    showMessageDialog(null, "Du angav n�got annat �n ett heltal.");
	  }
    }
  }
  
  
  public static boolean compareIntegers(int input, int computerGuess, int guessAmount) {
      if(input == computerGuess) {
    	  showMessageDialog(null, "R�tt gissat! " + "Du gissade " + guessAmount + " g�nger.");
    	  return true;
      } else if (input > computerGuess) {
    	  showMessageDialog(null, "Ditt tal �r f�r stort!");
      } else {
    	  showMessageDialog(null, "Ditt tal �r f�r litet!");
      }
      
      return false;
  }
}

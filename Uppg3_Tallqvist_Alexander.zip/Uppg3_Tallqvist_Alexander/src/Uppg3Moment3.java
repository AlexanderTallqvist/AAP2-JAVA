import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.util.Arrays;

public class Uppg3Moment3 {
	
	 public static void main(String[] args) {
		 
		 int[] lotteryNumbers = generateRandomArray();
		 int userGuessAmount = 0;
		 String[] userLottoRow;
		 boolean validInput = false;
		 
		 // Print correct row for testing
		 //System.out.println(Arrays.toString(lotteryNumbers));
		 
		 while (validInput == false) { 
			 
			 try {
				 userLottoRow = showInputDialog(null, "Ange en lottorade med 7 heltal (1-39). Av�nd mellanslag mellan siffrorna.", "Lottorad", QUESTION_MESSAGE).split("\\s+");
				 
				 if(checkIfValidRow(userLottoRow)) {
					 userGuessAmount++;
					 
					 if(getResults(userLottoRow, lotteryNumbers)) {
						 showMessageDialog(null, "Du har vunnit! Antal gissningar: " + userGuessAmount + ". Den slutliga raden var: " + Arrays.toString(lotteryNumbers));
						 validInput = true;
					 }
				 }
 
			 } 
			 
		    catch (NumberFormatException e ) {
		    	showMessageDialog(null, "Lottoraden f�r endast inneh�lla heltal!"); 	 	    
		    }
			 
			catch (Exception e) {
				 String message = e.getMessage();
				 
				 if(e.getMessage() == null) {
					 message = "Ange en giltig lottorad!";
				 }
				 
				 showMessageDialog(null, message); 	 
			 }
		 }
		 
	 }
	 
	 
	 // Generate random lotto array
	 public static int[] generateRandomArray() {
		int[] randomArray = new int[7];
		int randomNumber;
		boolean checkDuplicate;
		
		for(int i = 0; i < 7; i ++) {
			
			checkDuplicate = false;
			
			while(checkDuplicate == false) {
				
				randomNumber = (int)(Math.random() * 39 + 1);
				
				if(!contains(randomArray, randomNumber)) {
					randomArray[i] = randomNumber;
					checkDuplicate = true;
				} 
			}
		}
		
		return randomArray;
	}
	 

	 // Check for duplicates when creating the random lotto array
	 public static boolean contains(int[] array, int number) {
		 for (int n : array) {
			 if (number == n) {
	            return true;
	         }
	      }
	      return false;
	 }
	 
	 
	 // Check if the user lotto row is valid
	 public static boolean checkIfValidRow(String[] array) throws Exception {
		 
		 if(array.length != 7 ) {
			 throw new Exception("Raden har inte korrekt l�ngd!");
		 }
		 
		 for(int i = 0; i < 7; i ++) {		 
			 
			 if (tooManyOccurances(array, Integer.parseInt(array[i]))) {
				 throw new Exception("Ett tal kan endast anv�ndas en g�ng i din lottorad!");
			 }
		   
			 if (Integer.parseInt(array[i]) > 39) {
				 throw new Exception("Talet " + array[i] + " �r f�r stort. Ange endast tal meallan 1- 39!");
	         }
			 
			 if (Integer.parseInt(array[i]) < 1) {
				 throw new Exception("Talet " + array[i] + " �r f�r litet. Ange endast tal meallan 1- 39!");
	         }
			 
		 }
	      return true;
	 }
	 	 
	 
	 // Check if the user lotto row has duplicates
	 public static boolean tooManyOccurances(String[] userLottoRow, int number) {
		 int numberOfOccurances = 0;
		 
		 for(int i = 0; i < 7; i ++) {
			if( Integer.parseInt(userLottoRow[i]) == number) {
				numberOfOccurances++;
			}
		 }
		 
		 if(numberOfOccurances > 1) {
			 return true;
		 } else {
			 return false;
		 }
	 }
	 
	 
	 // Compare the user lotto row to the randomly generated row
	 public static boolean getResults(String[] userLottoRow, int[] lotteryNumbers) {
		 String correctNumbers = " ";
		 int amountOfCorrectNumbers = 0;
		 
		 for(int i = 0; i < 7; i ++) {
			 for(int j = 0; j < 7; j ++) { 
				 if(Integer.parseInt(userLottoRow[i]) == lotteryNumbers[j]) {
					 correctNumbers += userLottoRow[i] + ", ";
					 amountOfCorrectNumbers++;	 
				 } 
	         } 
		 }
		 		 
		 if(amountOfCorrectNumbers == 7) {
			 return true;
		 } else {
			 showMessageDialog(null, "Talen du fick r�tt:" + correctNumbers + " \nGissa 7 nya tal.");
			 return false;
		 }
		 
	 }
}

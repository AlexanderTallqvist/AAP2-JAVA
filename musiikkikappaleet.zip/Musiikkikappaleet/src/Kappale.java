public class Kappale {

	private String artist;
	private String song;
	private double length;
	
	Kappale(String artist, String song, double length) {
		this.artist = artist;
		this.song = song;
		this.length = length;
	}
	
	public String getArtist() {
		return artist;
	}
	
	public void setArtist(String artist) {
		this.artist = artist;
	}
	
	public String getSong() {
		return song;
	}
	
	public void setSong(String song) {
		this.song = song;
	}
	
	public double getLength() {
		return length;
	}
	
	public void setLength(double length) {
		this.length = length;
	}
	
}
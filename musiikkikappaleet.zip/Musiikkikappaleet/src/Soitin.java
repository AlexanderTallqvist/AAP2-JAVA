import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Soitin {

	public static void main(String[] args) {
		
		List<Kappale> trackList = new ArrayList<Kappale>();
		String userInput;
		boolean valdInput = true;
		
		while (valdInput == true) {

			try {
				userInput = showInputDialog(null, "Mit� haluat tehd�?\nL = Kappalelista\nP = Poista kappale\n"
						  + "V = Vaihda paikkaa\nN = N�yt� kappalelist\nS = Sulje ohjelma", "Soitin", QUESTION_MESSAGE);
				
				// Call the correct method depending on user input
				if("L".equals(userInput)) {
					trackList = addTrack(trackList);
				}
				
				else if("P".equals(userInput)) {
					trackList = removeTrack(trackList);
				}
				
				else if("V".equals(userInput)) {
					trackList = swapTrackPosition(trackList);
				}
				
				else if("N".equals(userInput)) {
					displayTrackList(trackList);
				}
				
				else if("S".equals(userInput)) {
					throw new Exception();
				}
				
				else {
					throw new Exception();
				}
				
				
			} catch (Exception e) {
				showMessageDialog(null, "Ohjelma suljetaan.");
				valdInput = false;
			}
		}

	}
	
	// Method for adding a track to the list
	public static List<Kappale> addTrack (List<Kappale> trackList) {
		String artist = showInputDialog(null, "Anna artisti", "Lis�� Kappale", QUESTION_MESSAGE);
		String song   = showInputDialog(null, "Anna kappale", "Lis�� Kappale", QUESTION_MESSAGE);
		double length = Double.parseDouble(showInputDialog(null, "Anna kappaleen pituus", "Lis�� Kappale", QUESTION_MESSAGE));
		
		Kappale track = new Kappale(artist, song, length);
		trackList.add(track);
		return trackList;
	}
	
	// Method for removing a track from the list
	public static List<Kappale> removeTrack (List<Kappale> trackList) {
		int trackIndex = Integer.parseInt(showInputDialog(null, "Anna poistettavan kappaleen numero", "Poista Kappale", QUESTION_MESSAGE));
		trackList.remove(trackIndex - 1);
		return trackList;
	}
	
	// Method for printing out the list
	public static void displayTrackList (List<Kappale> trackList) {
		String message = "";
		
		for (int i = 0; i < trackList.size(); i++) {
			message += "Kappale: " + (i + 1) + "\n"
					+  "Kappaleen artisti: " + trackList.get(i).getArtist() + "\n"
					+  "Kappaleen nimi: " + trackList.get(i).getSong() + "\n"
					+  "Kappaleen pituus: " + trackList.get(i).getLength() + "\n\n";
		}
		
		showMessageDialog(null, message);
	}
	
	// Method for swapping the positions of two tracks in the list
	public static List<Kappale> swapTrackPosition (List<Kappale> trackList) {
		int trackIndex1 = Integer.parseInt(showInputDialog(null, "Anna ensimm�isen kappaleen numero", "Vaihda paikkaa", QUESTION_MESSAGE));
		int trackIndex2 = Integer.parseInt(showInputDialog(null, "Anna toisen kappaleen numero", "Vaihda paikkaa", QUESTION_MESSAGE));
		
		Collections.swap(trackList, trackIndex1-1, trackIndex2-1);
		return trackList;
	}
	
}

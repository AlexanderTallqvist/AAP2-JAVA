import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Scanner;

public class Utilities {

	
	// Helper method that saves all Class objects to text files
	public static void saveToFile(ArrayList<Object> classObjects, String fileName) {
		
		String outString = "";
		
		if(!classObjects.isEmpty()) {
			for(int i = 0; i < classObjects.size(); i++) {

				try {
					Object currentObject = classObjects.get(i);
					Method saveMethod    = currentObject.getClass().getMethod("getSaveString");
					outString	        += saveMethod.invoke(currentObject);
				} catch (Exception e) {
					System.out.println("Sparingsinformation hittades inte.");
				}
			}
			
			try {
				PrintWriter out = new PrintWriter("src/TextFiles/" + fileName);

				outString = outString.substring(0, outString.length() - 1);
				out.println(outString);	
				out.close();
				
			} catch (FileNotFoundException e) {
				System.out.print("Filen hittades inte");
			}	
		}
	}
	
	
	// Helper method that prints out the information inside an ArrayList of objects
	public static String printObjectsInfo(ArrayList<Object> objectList) {
		String stringToPrint = "";
		
		for(int i = 0; i < objectList.size(); i++) { 
			try {
				Object currentObject = objectList.get(i);
				Method infoMethod    = currentObject.getClass().getMethod("getInformation");
				stringToPrint       += infoMethod.invoke(currentObject);
			} catch (Exception e) {
				System.out.println("Informationen hittades inte.");
			}	
		}
		
		return stringToPrint;
	}
	
	
	// Helper method that creates various objects with the data from a text file
	public static ArrayList<Object> createObjectsFromFile(String fileName, String className) {
		ArrayList<String> objectStrings = readFile(fileName);
		ArrayList<Object> classInstances = new ArrayList<>();
		
		if(!objectStrings.isEmpty()) {
			Class<?> classToCreate = null;
			
			try {
				classToCreate = Class.forName(className);

				for(int i = 0; i < objectStrings.size(); i++) {
					String anObjectString = objectStrings.get(i);
					classInstances.add(classToCreate.getDeclaredConstructor(String.class).newInstance(anObjectString));
				}
			}
			
			catch (Exception e) { 
				System.out.println("Det gick inte att l�sa int filen " + fileName);
			}
			
			return classInstances;
		}
		
		return classInstances;
	}
	
	
	// Helper method that reads a text file
	public static ArrayList<String> readFile(String fileName) {
		ArrayList<String> fileData = new ArrayList<String>();
		
		try {
			Scanner in = new Scanner(new FileReader("src/TextFiles/" + fileName));
			while (in.hasNextLine()) {
				fileData.add(in.nextLine());
			}
			
			in.close();
			return fileData;
			
		} catch (FileNotFoundException e) {
			System.out.println("Det gick inte att l�sa int filen " + fileName);
		}
		
		return null;
	}
}

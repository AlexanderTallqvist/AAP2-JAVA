import java.lang.reflect.Method;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Lager {

	protected int h�jd;
	
	protected int bredd;
	
	protected int saldo;
	
	protected int trigger = 5;
	
	protected double ink�pspris;
	
	protected double nettopris;
	
	

	public Lager(String lagerString) {
		
		try {
			String[]legoBit = lagerString.split(",");
			this.h�jd = Integer.parseInt(legoBit[0]);
			this.bredd = Integer.parseInt(legoBit[1]);
			this.saldo = Integer.parseInt(legoBit[2]);
			this.trigger = Integer.parseInt(legoBit[3]);
			this.ink�pspris = Double.parseDouble(legoBit[4]);
			this.nettopris = Double.parseDouble(legoBit[5]);	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Lagret gick inte att uppdatera.");
		}
	}
	
	// Method that displays information about the stock situation
	public String getInformation() {
		String returnString = "";
		returnString += "Bitens h�jd: " + h�jd + "\n";
		returnString += "Bitens bredd: " + bredd + "\n";
		returnString += "Bitar kvar: " + saldo + "\n";
		returnString += "Bitens ink�pspris: " + ink�pspris + "\n";
		returnString += "Bitens nettopris: " + nettopris + "\n";
		returnString += "Varning vid: " + trigger + " bitar kvar\n\n";
		return returnString;
	}
	
	// Method that gets information about the total stock value
	public static String getTotalStockValue(ArrayList<Object> objectList) {
		double totalAmount = 0, currentObjectValue;
		int currentObjectAmount;

		for(int i = 0; i < objectList.size(); i++) { 
			try {
				Object currentObject = objectList.get(i);
				
				Method amountMethod  = currentObject.getClass().getMethod("getSaldo");
				currentObjectAmount  = (int) amountMethod.invoke(currentObject);
				
				Method valueMethod   = currentObject.getClass().getMethod("getNettopris");
				currentObjectValue   = (double) valueMethod.invoke(currentObject);
				
				totalAmount += currentObjectAmount * currentObjectValue;
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Lagrets totaltv�rde kunde inte kalkyleras.");
			}	
		}
		
		return "\nLagrets totala v�rder �r: " + totalAmount + " �.";
	}
	
	// Method that returns the part prices when creating a new product
	public static double getNettoprisForProduct(ArrayList<Object> objectList, String partString) {
		double nettopris = 0;
		String[]parts = partString.split(",");
		
		for(int j = 0; j < parts.length; j++) { 
			
			String[]currentPart = parts[j].split("x");
			
			for(int i = 0; i < objectList.size(); i++) { 
				try {
					Object currentObject = objectList.get(i);
					Method heightMethod  = currentObject.getClass().getMethod("getH�jd");
					Method widthMethod   = currentObject.getClass().getMethod("getBredd");
					
					int partHeight = (int) heightMethod.invoke(currentObject);
					int parthWidth = (int) widthMethod.invoke(currentObject);
					
					if(Integer.parseInt(currentPart[1]) == partHeight && Integer.parseInt(currentPart[2]) == parthWidth) {
						Method priceMethod = currentObject.getClass().getMethod("getNettopris");
						double pris = (double) priceMethod.invoke(currentObject);
						nettopris += pris * Integer.parseInt(currentPart[0]);
					}
					
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Produktens nettopris kunde inte ber�knas.");
				}	
			}
	
		}
		
		return nettopris;
	}
	
	// Method that's used for adding new parts or updating old parts in the stock
	public static ArrayList<Object> addPartToStock(ArrayList<Object> objectList, String orderString) {
		
		String[]partToAdd = orderString.split(",");
		
		if(objectList.size() < 1) {
			objectList.add(new Lager(orderString));
			JOptionPane.showMessageDialog(null, "Ny bit inf�rts till lagret.");
			return objectList;
		}
		
		for(int i = 0; i < objectList.size(); i++) { 

			try {
				Object currentObject = objectList.get(i);
				Method heightMethod  = currentObject.getClass().getMethod("getH�jd");
				Method widthMethod   = currentObject.getClass().getMethod("getBredd");
				Method currentSaldo  = currentObject.getClass().getMethod("getSaldo");
				
				int partHeight   = (int) heightMethod.invoke(currentObject);
				int parthWidth   = (int) widthMethod.invoke(currentObject);
				int currentParts = (int) currentSaldo.invoke(currentObject);
				
				if(Integer.parseInt(partToAdd[0]) == partHeight && Integer.parseInt(partToAdd[1]) == parthWidth) {
					Method saldoMethod   = currentObject.getClass().getMethod("setSaldo", int.class);
					Method triggerMethod = currentObject.getClass().getMethod("setTrigger", int.class);
					Method inkopsMethod  = currentObject.getClass().getMethod("setInk�pspris", double.class);
					Method nettoMethod   = currentObject.getClass().getMethod("setNettopris", double.class);
					
					saldoMethod.invoke(currentObject,   Integer.parseInt(partToAdd[2]) + currentParts);
					triggerMethod.invoke(currentObject, Integer.parseInt(partToAdd[3]));
					inkopsMethod.invoke(currentObject,  Double.parseDouble(partToAdd[4]));
					nettoMethod.invoke(currentObject ,  Double.parseDouble(partToAdd[5]));
					
					JOptionPane.showMessageDialog(null, "Existerande bit har uppdaterats.");
					
					return objectList;
				}
				
				else {
					objectList.add(new Lager(orderString));
					JOptionPane.showMessageDialog(null, "Ny bit inf�rts till lagret.");
					return objectList;
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Lagret gick inte att uppdatera..");
			}	
		}	
		
		return objectList;
	}
	
	// Method for the new order message
	public static String newOrder() {
		String returnString = "";
		returnString  = "Ange ny best�llning av legobitar i f�ljande format:\n";
		returnString += "Bitens h�jdxBitens breddxBest�llningens storlek,Varning vid,Ink�pspris,Nettopris\n";
		returnString += "Exempel: 5,2,100,50,0.03,0.10";
		
		return returnString;
	}
	
	// Method for the order save string
	public String getSaveString() {
		String saveString = "";
		saveString  = this.getH�jd() + ",";
		saveString += this.getBredd() + ",";
		saveString += this.getSaldo() + ",";
		saveString += this.getTrigger() + ",";
		saveString += this.getInk�pspris() + ",";
		saveString += this.getNettopris() + "\n";

		return saveString;
	}
	
	// Method that is used to remove parts from the stock that are used in a new order
	public static ArrayList<Object> removeOrderParts(String orderParts, ArrayList<Object> allParts) {

		String[]products = orderParts.split(",");
		
		for(int i = 0; i < products.length; i++) {
			
			String[]productParts = products[i].split("x");
			int partAmount = Integer.parseInt(productParts[0]);
			int partHeight = Integer.parseInt(productParts[1]);
			int partWidth  = Integer.parseInt(productParts[2]);
			
			for(int j = 0; j < allParts.size(); j++) {	
				
				try {
					Object currentObject = allParts.get(j);
					Method heightMethod  = currentObject.getClass().getMethod("getH�jd");
					Method widthMethod   = currentObject.getClass().getMethod("getBredd");
					
					int height = (int) heightMethod.invoke(currentObject);
					int width  = (int) widthMethod.invoke(currentObject);
					
					if(partHeight == height && partWidth == width) {
	
						Method getStockMethod = currentObject.getClass().getMethod("getSaldo");
						Method setStockMethod = currentObject.getClass().getMethod("setSaldo", int.class);
						Method triggerMethod  = currentObject.getClass().getMethod("getTrigger");
						
						int currentAmount = (int) getStockMethod.invoke(currentObject);
						int triggerAmount = (int) triggerMethod.invoke(currentObject);
						int newAmount     = currentAmount - partAmount;
						
						if(newAmount < triggerAmount) {
							String warningMessage = "";
							warningMessage  = "Biten med h�jd " + height + " och bredd " + width + " ligger under varningsgr�nssen!\n";
							warningMessage += "Bitar kvar: " + newAmount + ". Best�ll mera bitar!\n";
							JOptionPane.showMessageDialog(null, warningMessage);
						}
						
						setStockMethod.invoke(currentObject, newAmount);
					}
					
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Produktens bitar kune inte tas bort fr�n lagret.");
				}
				
			}
			
		}

		return allParts;
	}

	// Getters and Setters
	public int getH�jd() {
		return h�jd;
	}

	public void setH�jd(int h�jd) {
		this.h�jd = h�jd;
	}

	public int getBredd() {
		return bredd;
	}

	public void setBredd(int bredd) {
		this.bredd = bredd;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	public int getTrigger() {
		return trigger;
	}

	public void setTrigger(int trigger) {
		this.trigger = trigger;
	}

	public double getInk�pspris() {
		return ink�pspris;
	}

	public void setInk�pspris(double ink�pspris) {
		this.ink�pspris = ink�pspris;
	}

	public double getNettopris() {
		return nettopris;
	}

	public void setNettopris(double nettopris) {
		this.nettopris = nettopris;
	}
	
}

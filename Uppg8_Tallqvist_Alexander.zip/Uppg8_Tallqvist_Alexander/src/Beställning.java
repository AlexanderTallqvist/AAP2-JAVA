import javax.swing.JOptionPane;

public class Best�llning {

	protected String best�llarensF�rnamn;
	
	protected String best�llarensEfternamn;
	
	protected String produktNamn;
	
	protected String arbetareF�rnamn;
	
	protected String arbetareEfternamn;
	
	protected String arbetarId;
	
	public Best�llning(String best�llningsString) {
		
		try	{
			String[]best�llning = best�llningsString.split(",");
			best�llarensF�rnamn = best�llning[0];
			best�llarensEfternamn = best�llning[1];
			produktNamn = best�llning[2];
			arbetareF�rnamn = best�llning[3];
			arbetareEfternamn = best�llning[4];
			arbetarId = best�llning[5];	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Best�lningen kunde inte inf�ras i systemet.");
		}
	}
	
	// Method for the new order message
	public static String nyBest�llning() {
		String returnString = "";
		returnString  = "Ange ny best�llning i f�ljande format:\n";
		returnString += "Best�llarens f�rnamn,Best�llarens efternamn, Produkt, Arbetare f�rnamn, Arbetare efternman, Arbetar ID\n";
		returnString += "Exempel: Hans,Herman,Polisstation,Alexander,Tallqvist,11953b2a\n";
		
		return returnString;
				
	}
	
	// Method for the product save string
	public String getSaveString() {
		String saveString = "";
		saveString  = this.getBest�llarensF�rnamn() + ",";
		saveString += this.getBest�llarensEfternamn() + ",";
		saveString += this.getProduktNamn() + ",";
		saveString += this.getArbetareF�rnamn() + ",";
		saveString += this.getArbetareEfternamn() + ",";
		saveString += this.getArbetarId() + "\n";
		
		return saveString;
	}
	
	// Method that returns the information string about the orders
	public String getInformation() {
		String returnString;
		returnString  = "Best�llarens namn: " + this.getBest�llarensF�rnamn() + " " + this.getBest�llarensEfternamn() +"\n";
		returnString += "Produktens namn: " + this.getProduktNamn() + "\n";
		returnString += "Arbetare: " + this.getArbetareF�rnamn() + " " + this.getArbetareEfternamn() + ", ID: " + this.getArbetarId() +  "\n\n";
		
		return returnString;
				
	}
	
	// Getters and Setters
	public String getBest�llarensF�rnamn() {
		return best�llarensF�rnamn;
	}

	public void setBest�llarensF�rnamn(String best�llarensF�rnamn) {
		this.best�llarensF�rnamn = best�llarensF�rnamn;
	}

	public String getBest�llarensEfternamn() {
		return best�llarensEfternamn;
	}

	public void setBest�llarensEfternamn(String best�llarensEfternamn) {
		this.best�llarensEfternamn = best�llarensEfternamn;
	}

	public String getProduktNamn() {
		return produktNamn;
	}

	public void setProduktNamn(String produktNamn) {
		this.produktNamn = produktNamn;
	}

	
	public String getArbetareF�rnamn() {
		return arbetareF�rnamn;
	}

	public void setArbetareF�rnamn(String arbetareF�rnamn) {
		this.arbetareF�rnamn = arbetareF�rnamn;
	}

	public String getArbetareEfternamn() {
		return arbetareEfternamn;
	}

	public void setArbetareEfternamn(String arbetareEfternamn) {
		this.arbetareEfternamn = arbetareEfternamn;
	}

	public String getArbetarId() {
		return arbetarId;
	}

	public void setArbetarId(String arbetarId) {
		this.arbetarId = arbetarId;
	}

}

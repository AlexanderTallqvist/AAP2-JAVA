import java.lang.reflect.Method;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;


import javax.swing.JOptionPane;

public class Arbetare {

	protected String f�rnamn;
	
	protected String efternamn;
	
	protected String arbetsUppgigt;
	
	protected String narUppgiftenBorjade;
	
	protected String narUppgiftenSlutar;
	
	protected boolean arbetar;
	
	protected String uniqueID;
	
	
	Arbetare(String arbetarString) {
		try {
			
			String[]worker = arbetarString.split(",");
			this.f�rnamn = worker[0];
			this.efternamn = worker[1];
			this.arbetsUppgigt = worker[2];
			this.narUppgiftenBorjade = worker[3];
			this.narUppgiftenSlutar = worker[4];
			this.arbetar = Boolean.parseBoolean(worker[5]);
			this.uniqueID = worker[6];	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Arbetaren kunde inte f�ras in i systemet.");
		}
	}
	
	// Method for the new worker message
	public static String nyArbetare() {
		String returnString = "";
		returnString  = "Ange ny arbetare i f�ljande format:\n";
		returnString += "Arbetarens f�rnamn,Arbetarens efternamn\n";
		returnString += "Exempel: Hans,Herman";
		
		return returnString;
	}
	
	// Method for the worker save string
	public String getSaveString() {
		String saveString = "";
		saveString  = this.getF�rnamn() + ",";
		saveString += this.getEfternamn() + ",";
		saveString += this.getArbetsUppgigt() + ",";
		saveString += this.getNarUppgiftenBorjade() + ",";
		saveString += this.getNarUppgiftenSlutar() + ",";
		saveString += this.isArbetar()  + ",";
		saveString += this.getUniqueID()  + "\n";
		
		return saveString;
	}
	
	// Method that displays information about the workers
	public String getInformation() {
		String returnString = "";
		returnString += "F�rnamn: " + this.getF�rnamn() + "\n";
		returnString += "Efternamn: " + this.getEfternamn() + "\n";
		returnString += "Arbetsuppgift: " + this.getArbetsUppgigt() + "\n";
		returnString += "N�r uppgiften b�rjade: " + this.getNarUppgiftenBorjade() + "\n";
		returnString += "N�r uppgiften slutar: " + this.getNarUppgiftenSlutar() + "\n";
		returnString += "ID: " + this.getUniqueID() + "\n\n";
		return returnString;
	}
	
	// Method that removes a worker by ID
	public static ArrayList<Object> removeWorker(ArrayList<Object> allWorkers, String workerID) {
		
		for(int i = 0; i < allWorkers.size(); i++) { 
			try {
				Object currentObject = allWorkers.get(i);
				Method infoMethod    = currentObject.getClass().getMethod("getUniqueID");
				
				// Remove workers if ID's match
				if(workerID.equals(infoMethod.invoke(currentObject))) {
					allWorkers.remove(i);
					JOptionPane.showMessageDialog(null, "Arbetare med ID: " + workerID + " borttagen.");
					return allWorkers;
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,"N�gonting gick fel. Arbetaren kunde inte tas bort.");
			}	
		}
		
		JOptionPane.showMessageDialog(null,"Arbetaren med ID " + workerID + " hittades inte.");
		return allWorkers;
	}
	
	// Method that gets the available workers when placing a new order
	public static String getAvailableWorkers(ArrayList<Object> allWorkers) {
		String returnString = "\nLEDIGA ARBETARE:\n";
		boolean workersFound = false;
		
		for(int i = 0; i < allWorkers.size(); i++) { 
			try {
				Object currentObject   = allWorkers.get(i);
				Method isWorkingMethod = currentObject.getClass().getMethod("isArbetar");
				
				// Get worker information if ID matches
				if(isWorkingMethod.invoke(currentObject).equals(false)) {

					Method firstNameMethod = currentObject.getClass().getMethod("getF�rnamn");
					Method lastNameMethod  = currentObject.getClass().getMethod("getEfternamn");
					Method workerIdMethod  = currentObject.getClass().getMethod("getUniqueID");
					
					String firstName = (String) firstNameMethod.invoke(currentObject);
					String lastName  = (String) lastNameMethod.invoke(currentObject);
					String workerId  = (String) workerIdMethod.invoke(currentObject);
					
					returnString += "Arbetare: " + firstName + " " + lastName + ", ID: " + workerId + "\n";
					workersFound = true;
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,"N�gonting gick fel. Inga arbetare hittades.");
			}	
		}
		
		if(!workersFound) {
			returnString = "Inga arbetare hittades.";
		}
		
		return returnString;
	}
	
	// Method for setting a new task for a worker
	// OBS! We assume that the work tasks will be administered during working hours (9-17)
	// Use the code that is commented out below for testing the program at another time.
	public static ArrayList<Object> setNewTask(ArrayList<Object> allWorkers, String workTime, String workerId, String productToOrder) {

		for(int i = 0; i < allWorkers.size(); i++) { 
			try {
				Object currentObject  = allWorkers.get(i);
				Method workerIdMethod = currentObject.getClass().getMethod("getUniqueID");
				
				// Set the new task for the selected worker
				if(workerIdMethod.invoke(currentObject).equals(workerId)) {
				
				    LocalDateTime startTime = LocalDateTime.now();
				    LocalDateTime endTime = LocalDateTime.now().plusMinutes(Integer.parseInt(workTime));
				    LocalDateTime nextDay = LocalDateTime.now().plusDays(1);
				    
//				    FOR TESTING PURPOSES
//					LocalDateTime startTime = LocalDateTime.of(2017, 12, 4, 16, 30);
//				    LocalDateTime endTime = startTime.plusMinutes(Integer.parseInt(workTime));
//				    LocalDateTime nextDay = startTime.plusDays(1);
				    
				    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy - HH:mm");
				  
				    
				    // The worker is able to complete the task during the day it was set
				    if(startTime.getDayOfWeek().equals(endTime.getDayOfWeek()) && endTime.getHour() < 17 && endTime.getHour() > 9) {

				    	Method setTaskMethod      = currentObject.getClass().getMethod("setArbetsUppgigt", String.class);
				    	Method setWorkingMethid   = currentObject.getClass().getMethod("setArbetar", boolean.class);
				    	Method setTaskStartMethod = currentObject.getClass().getMethod("setNarUppgiftenBorjade", String.class);
				    	Method setTaskEndMethod   = currentObject.getClass().getMethod("setNarUppgiftenSlutar", String.class);
				    	
				    	setTaskMethod.invoke(currentObject, productToOrder);
				    	setWorkingMethid.invoke(currentObject, true);
				    	setTaskStartMethod.invoke(currentObject, startTime.format(formatter));
				    	setTaskEndMethod.invoke(currentObject, endTime.format(formatter));
				    }
				    
				    // Add the remaining minutes to the next day if the next day isn't on the weekend
				    else if (!((nextDay.getDayOfWeek().toString() == "SATURDAY") || (nextDay.getDayOfWeek().toString() == "SUNDAY"))) {

				    	int year  = startTime.getYear();
				    	int month = startTime.getMonthValue();
				    	int day   = startTime.getDayOfMonth();
				    	
				    	LocalDateTime endOfthisDay = LocalDateTime.of(year, month, day, 17, 0);
				    	
				    	int minutesLeftOfDay = (int) Duration.between(startTime, endOfthisDay).toMinutes();
				    	int minutesNextDay   = Integer.parseInt(workTime) - minutesLeftOfDay;
				    	
				    	int hours = minutesNextDay / 60;
				    	int minutesLeft = minutesNextDay % 60;
				    	LocalDateTime nextWorkingDay = LocalDateTime.of(year, month, day + 1, 9 + hours, 0 + minutesLeft);
				    	
				    	Method setTaskMethod      = currentObject.getClass().getMethod("setArbetsUppgigt", String.class);
				    	Method setWorkingMethid   = currentObject.getClass().getMethod("setArbetar", boolean.class);
				    	Method setTaskStartMethod = currentObject.getClass().getMethod("setNarUppgiftenBorjade", String.class);
				    	Method setTaskEndMethod   = currentObject.getClass().getMethod("setNarUppgiftenSlutar", String.class);
				    	
				    	setTaskMethod.invoke(currentObject, productToOrder);
				    	setWorkingMethid.invoke(currentObject, true);
				    	setTaskStartMethod.invoke(currentObject, startTime.format(formatter));
				    	setTaskEndMethod.invoke(currentObject, nextWorkingDay.format(formatter));

				    } 
				    
				    // Add the remaining minutes to the following Monday
				    else {
				    	System.out.println("NO HERE");
				    	LocalDateTime dateForNextMonay = startTime.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
				    	int MondayYear  = dateForNextMonay.getYear();
				    	int MondayMonth = dateForNextMonay.getMonthValue();
				    	int MondayDay   = dateForNextMonay.getDayOfMonth();
				    	
				    	int year  = startTime.getYear();
				    	int month = startTime.getMonthValue();
				    	int day   = startTime.getDayOfMonth();
				    	
				    	LocalDateTime endOfthisDay = LocalDateTime.of(year, month, day, 17, 0);
				    	
				    	int minutesLeftOfDay = (int) Duration.between(startTime, endOfthisDay).toMinutes();
				    	int minutesNextDay   = Integer.parseInt(workTime) - minutesLeftOfDay;
				    	
				    	int hours = minutesNextDay / 60;
				    	int minutesLeft = minutesNextDay % 60;
				    	LocalDateTime nextMonday = LocalDateTime.of(MondayYear, MondayMonth, MondayDay, 9 + hours, 0 + minutesLeft);
				    	
				    	Method setTaskMethod      = currentObject.getClass().getMethod("setArbetsUppgigt", String.class);
				    	Method setWorkingMethid   = currentObject.getClass().getMethod("setArbetar", boolean.class);
				    	Method setTaskStartMethod = currentObject.getClass().getMethod("setNarUppgiftenBorjade", String.class);
				    	Method setTaskEndMethod   = currentObject.getClass().getMethod("setNarUppgiftenSlutar", String.class);
				    	
				    	setTaskMethod.invoke(currentObject, productToOrder);
				    	setWorkingMethid.invoke(currentObject, true);
				    	setTaskStartMethod.invoke(currentObject, startTime.format(formatter));
				    	setTaskEndMethod.invoke(currentObject, nextMonday.format(formatter));
				    }
					
				} else {
					throw new Exception();
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Arbetaren kunde inte tilldelas arbetsuppgiften.");
			}	
		}
		
		return allWorkers;
	}
	
	// Method that updates the workers' schedule 
	public static ArrayList<Object> clearWorkerSchedules(ArrayList<Object> allWorkers) {
		
		for(int i = 0; i < allWorkers.size(); i++) { 
			try {
				Object currentObject   = allWorkers.get(i);
				Method isWorkingMethod = currentObject.getClass().getMethod("isArbetar");
				
				// Check if the task is done
				if(isWorkingMethod.invoke(currentObject).equals(true)) {

					Method workEndsMethod = currentObject.getClass().getMethod("getNarUppgiftenSlutar");
					String endDateString  = (String) workEndsMethod.invoke(currentObject);
					
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy - HH:mm");
					
					LocalDateTime endOfWork   = LocalDateTime.from(formatter.parse(endDateString));
					LocalDateTime currentTime = LocalDateTime.now();
					
					if(currentTime.isAfter(endOfWork)) {
				    	Method setTaskMethod      = currentObject.getClass().getMethod("setArbetsUppgigt", String.class);
				    	Method setWorkingMethid   = currentObject.getClass().getMethod("setArbetar", boolean.class);
				    	Method setTaskStartMethod = currentObject.getClass().getMethod("setNarUppgiftenBorjade", String.class);
				    	Method setTaskEndMethod   = currentObject.getClass().getMethod("setNarUppgiftenSlutar", String.class);
				    	
				    	setTaskMethod.invoke(currentObject, "Ingen uppgift");
				    	setWorkingMethid.invoke(currentObject, false);
				    	setTaskStartMethod.invoke(currentObject, "Ingen uppgift");
				    	setTaskEndMethod.invoke(currentObject, "Ingen uppgift");

					}
					
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Det gick inte att ta bort gamla arbetsuppgifter.");
			}	
		}
		
		return allWorkers;
	}
	
	// Getters and Setters
	public String getF�rnamn() {
		return f�rnamn;
	}

	public void setF�rnamn(String f�rnamn) {
		this.f�rnamn = f�rnamn;
	}

	public String getEfternamn() {
		return efternamn;
	}

	public void setEfternamn(String efternamn) {
		this.efternamn = efternamn;
	}

	public String getArbetsUppgigt() {
		return arbetsUppgigt;
	}

	public void setArbetsUppgigt(String arbetsUppgigt) {
		this.arbetsUppgigt = arbetsUppgigt;
	}

	public String getNarUppgiftenBorjade() {
		return narUppgiftenBorjade;
	}

	public void setNarUppgiftenBorjade(String narUppgiftenBorjade) {
		this.narUppgiftenBorjade = narUppgiftenBorjade;
	}
	
	public String getNarUppgiftenSlutar() {
		return narUppgiftenSlutar;
	}

	public void setNarUppgiftenSlutar(String narUppgiftenSlutar) {
		this.narUppgiftenSlutar = narUppgiftenSlutar;
	}

	public boolean isArbetar() {
		return arbetar;
	}

	public void setArbetar(boolean arbetar) {
		this.arbetar = arbetar;
	}

	public String getUniqueID() {
		return uniqueID;
	}

	public void setUniqueID(String uniqueID) {
		this.uniqueID = uniqueID;
	}
	
	
}

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Produkt {
	
	protected String namn;
	
	protected List<ArrayList<Integer>> bitar = new ArrayList<>();
	
	protected double nettopris;
	
	protected int arbetstid;
	
	// Constructor for new products
	public Produkt(String produktString, boolean newProduct) {
		
		try {
			String[]produkt = produktString.split("#");
			String[]produktBitar = produkt[0].split(",");
			String[]produktInfo  = produkt[1].split(",");
			
			// Set general info
			namn = produktInfo[0];
			arbetstid  = Integer.parseInt(produktInfo[1]);
			
			// Calculate price for product
			Double arbetsPris = Double.parseDouble(produktInfo[1]) * 0.5;
			Double bitPris    = Double.parseDouble(produktInfo[2]);
			nettopris  		  = bitPris + arbetsPris;
			
			// Add needed parts to the "bitar" ArrayList
			for(int i = 0; i < produktBitar.length; i++) {
				ArrayList<Integer> partArray = new ArrayList<>();
				String[]partInfo = produktBitar[i].split("x");
				
				for(int j = 0; j < partInfo.length; j++) {
					partArray.add(Integer.parseInt(partInfo[j]));
				}
				
				this.bitar.add(partArray);
			}	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Produkten kunde inte inf�ras i systemet.");
		}
		
	}
	
	// Constructor for existing products
	public Produkt(String produktString) {
		
		try {
			String[]produkt = produktString.split("#");
			String[]produktBitar = produkt[0].split(",");
			String[]produktInfo  = produkt[1].split(",");
			
			// Set general info
			namn = produktInfo[0];
			arbetstid  = Integer.parseInt(produktInfo[1]);
			
			// Calculate price for product
			nettopris = Double.parseDouble(produktInfo[2]);
			
			// Add needed parts to the "bitar" ArrayList
			for(int i = 0; i < produktBitar.length; i++) {
				ArrayList<Integer> partArray = new ArrayList<>();
				String[]partInfo = produktBitar[i].split("x");
				
				for(int j = 0; j < partInfo.length; j++) {
					partArray.add(Integer.parseInt(partInfo[j]));
				}
				
				this.bitar.add(partArray);
			}	
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Existerande produkter kunde inte inf�ras i systemet.");	
		}
		
	}
	
	// Method for the new product message
	public static String nyProdukt() {
		String returnString = "";
		returnString  = "Ange ny produkt i f�ljande format:\n";
		returnString += "Antal bitarxBitens h�jdxBitens bredd#Produktnamn,Arbetsminuter\n";
		returnString += "Exempel: 40x5x2,40x6x2#Brandstation,90";
		
		return returnString;
	}
	
	// Method for the product save string
	public String getSaveString() {
		String saveString = "";
		saveString  = this.getPartString() + "#";
		saveString += this.getNamn() + ",";
		saveString += this.getArbetstid() + ",";
		saveString += this.getNettopris() + "\n";

		return saveString;
	}
	
	// Method that formats the parts ArrayList to 100x5x2,300x6x3 etc..
	// Used when the products are saved to a file
	protected String getPartString() {
		String returnString = "";
		
		for(int i = 0; i < (int) bitar.size(); i++) {
			String partString = bitar.get(i).toString();
			partString = partString.replace(",", "x") .replace("[", "") .replace("]", "").replaceAll("\\s+","") + ","; 
			returnString +=partString;
		}
		
		returnString = returnString.substring(0, returnString.length() - 1);
		return returnString;
	}
	
	// Method that returns the information string about the products
	public String getInformation() {
		String returnString = "";
		returnString += "Produktens namn: " + this.getNamn() + "\n";
		returnString += "Produktens bitar: " + this.getPartString() + "\n";
		returnString += "Produktens nettopris: " + this.getNettopris() + "�\n";
		returnString += "Produktens arbetstid: " + this.getArbetstid() + " min\n\n";
		return returnString;
	}
	
	// Method that looks up a product by its name, and returns the parts and time needed for the product
	public static String getProductPartsAndTime(ArrayList<Object> allProducts, String productName) {
		
		String productPartsAndTime = null;
		
		for(int i = 0; i < allProducts.size(); i++) { 
			try {
				Object currentObject = allProducts.get(i);
				Method nameMethod    = currentObject.getClass().getMethod("getNamn");
				String nameOfProduct = (String) nameMethod.invoke(currentObject);
				
				// Get the parts for the product that we're ordering
				if(productName.toLowerCase().equals(nameOfProduct.toLowerCase())) {
					Method partsMethod = currentObject.getClass().getDeclaredMethod("getPartString");
					Method timeMethod  = currentObject.getClass().getDeclaredMethod("getArbetstid");
					
					productPartsAndTime = (String) partsMethod.invoke(currentObject);
					productPartsAndTime += "#" + (int) timeMethod.invoke(currentObject);
					return productPartsAndTime;
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Produktens delar och arbetstid hittades inte.");
			}	
		}
		
		return productPartsAndTime;
	}
	
	// Getters and setters
	public String getNamn() {
		return namn;
	}

	public void setNamn(String namn) {
		this.namn = namn;
	}

	public List<ArrayList<Integer>> getBitar() {
		return bitar;
	}

	public void setBitar(List<ArrayList<Integer>> bitar) {
		this.bitar = bitar;
	}

	public double getNettopris() {
		return nettopris;
	}

	public void setNettopris(double nettopris) {
		this.nettopris = nettopris;
	}

	public int getArbetstid() {
		return arbetstid;
	}

	public void setArbetstid(int arbetstid) {
		this.arbetstid = arbetstid;
	}
	
}

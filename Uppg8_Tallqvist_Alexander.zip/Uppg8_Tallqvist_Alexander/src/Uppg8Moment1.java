import java.util.ArrayList;
import java.util.UUID;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class Uppg8Moment1 {
	
	public static void main(String[] args)throws Exception { 
		
		ArrayList<Object> allWorkers  = Utilities.createObjectsFromFile("Arbetare.txt", "Arbetare");
		ArrayList<Object> allParts    = Utilities.createObjectsFromFile("Lager.txt", "Lager");
		ArrayList<Object> allProducts = Utilities.createObjectsFromFile("Produkter.txt", "Produkt");
		ArrayList<Object> allOrders   = Utilities.createObjectsFromFile("Bestallningar.txt", "Best�llning");

		int userInput;
		boolean keepRunning = true;
		
		while (keepRunning == true) {

			try {
				userInput = initUI();
				
				// New order
				if(userInput == 0) {
					// Get the "New order" message
					String message = Best�llning.nyBest�llning();
					
					// Update all the workers and their schedules
					Arbetare.clearWorkerSchedules(allWorkers);
					
					// Display the message
					message += Arbetare.getAvailableWorkers(allWorkers);
					message += "\nPRODUKTER SOM S�LJES:\n";
					message += Utilities.printObjectsInfo(allProducts);	
					String userOrder = JOptionPane.showInputDialog(message);
					
					// Get the users order
					String[]userString    = userOrder.split(",");
					String productToOrder = userString[2];
					String productWorker  = userString[5];
					
					// Get the parts for the product, and the time it takes to make the product
					String productPartsAndTime = Produkt.getProductPartsAndTime(allProducts, productToOrder);
					String[]productInfo = productPartsAndTime.split("#");
					String productParts = productInfo[0];
					String productTime  = productInfo[1];
					
					// Remove parts from the stock that will be used for the product
					// This will trigger a warning if the parts go beneath its trigger threshold
					allParts = Lager.removeOrderParts(productParts, allParts);
					
					// Give the new work order to the selected worker
					allWorkers = Arbetare.setNewTask(allWorkers, productTime, productWorker, productToOrder);
					
					// Add the order
					allOrders.add(new Best�llning(userOrder));

				}
				
				// Show orders
				else if(userInput == 1) {
					String outputMessage = "BEST�LDA PRODUKTER\n";
					outputMessage += Utilities.printObjectsInfo(allOrders);
					JOptionPane.showMessageDialog(null, outputMessage);
				}
				
				// New parts to stock
				else if(userInput == 2) {
					String message = Lager.newOrder();
					String userString = JOptionPane.showInputDialog(message);
					allParts = Lager.addPartToStock(allParts, userString);
					
				}			
				
				// Show stock situation
				else if(userInput == 3) {
					String outputMessage = "BITAR I LAGRET\n";
					outputMessage += Utilities.printObjectsInfo(allParts);
					outputMessage += Lager.getTotalStockValue(allParts);
					JOptionPane.showMessageDialog(null, outputMessage);
				}
				
				// New product
				else if(userInput == 4) {
					String message = Produkt.nyProdukt();
					String[]userString = JOptionPane.showInputDialog(message).split("#");
					String partString = userString[0];
					
					// Get the price for the product
					Double nettopris = Lager.getNettoprisForProduct(allParts, partString);
					
					if(nettopris > 0) {
						String constructorString = userString[0] + "#" + userString[1] + "," + nettopris;
						allProducts.add(new Produkt(constructorString, true));
					} else {
						JOptionPane.showMessageDialog(null, "N�gon av bitarne hittades inte. Produkten inf�rdes inte.");
					}
				}
				
				// Show all products
				else if(userInput == 5) {
					String outputMessage = "ALLA PRODUKTER\n";
					outputMessage += Utilities.printObjectsInfo(allProducts);
					JOptionPane.showMessageDialog(null, outputMessage);				
				}			
				
				// New worker
				else if(userInput == 6) {
					String message = Arbetare.nyArbetare();
					String[]userString = JOptionPane.showInputDialog(message).split(",");
					String[]workerId = UUID.randomUUID().toString().split("-");
					String newWorker = userString[0] + "," + userString[1] + "," + "Ingen uppgift" + "," + 
					"Ingen uppgift" + "," + "Ingen uppgift" + "," + "false" + "," + workerId[0];
					
					if(userString.length == 2) {
						allWorkers.add(new Arbetare(newWorker));	
					}
					
				}
				
				// Show all workers
				else if(userInput == 7) {
					Arbetare.clearWorkerSchedules(allWorkers);
					String outputMessage = "ALLA ARBETARE\n";
					outputMessage += Utilities.printObjectsInfo(allWorkers);
					JOptionPane.showMessageDialog(null, outputMessage);		
				}			
				
				// Remove worker
				else if(userInput == 8) {
					String outputMessage = "Ange arbetarens ID\n";
					outputMessage += "Exempel: 5f09003d";
					String workerID = JOptionPane.showInputDialog(null, outputMessage);
					allWorkers = Arbetare.removeWorker(allWorkers, workerID);
				}
				
				// The user hit the exit button
				else {
					JOptionPane.showMessageDialog(null, "Programmet st�ngs.");
					Utilities.saveToFile(allOrders, "Bestallningar.txt");
					Utilities.saveToFile(allWorkers, "Arbetare.txt");
					Utilities.saveToFile(allProducts, "Produkter.txt");
					Utilities.saveToFile(allParts, "Lager.txt");
					keepRunning = false;
				}
				
			} 
			catch (Exception e) {
				JOptionPane.showMessageDialog(null, "N�gonting gick fel. Programmet st�ngs.");
				keepRunning = false;
			}
		}
	}
	
	// Create the GUI
    public static int initUI() {
        String[] buttons = { "Ny best�llning", "Visa best�llningar", 
        		"Nya bitar till lagret", "Visa lagersituation", "Ny produkt", 
        		"Alla produkter", "Ny arbetare", "Alla arbetare", "Ta bort arbetare" }; 

        JComboBox<String> combo = new JComboBox<String>(buttons);
        int result = JOptionPane.showConfirmDialog(
                null,
                combo,
                "Vad vill du g�ra?",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            return combo.getSelectedIndex();
        }
		return result;
    }
}
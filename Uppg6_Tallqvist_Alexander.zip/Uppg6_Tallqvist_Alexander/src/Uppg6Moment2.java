import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showOptionDialog;
import javax.swing.JFrame;

public class Uppg6Moment2 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		boolean animalExists;
		int userInput, nextIndex = 0;
		Djur[] animals = new Djur[5];
		String[]animal;
		
		// Message box
		JFrame frame = new JFrame();
		String[] options = new String[2];
		options[0] = new String("L�gg till ett djur.");
		options[1] = new String("Visa alla djur.");

		while (validInput == true) {

			try {
				userInput = showOptionDialog(frame.getContentPane(), "Vad vill du g�ra?", "Djurparken", 0, INFORMATION_MESSAGE, null, options, null);
				
				// Add animal to the animals array
				if(userInput == 0) {
					animalExists = false;
					animal = showInputDialog(null, "Ange djur och l�te i fromen: 'Djur, L�te'", "L�gg till djur", QUESTION_MESSAGE).toLowerCase().split(",");
					
					String animalType  = animal[0].trim();
					String animalSound = animal[1].trim();
					
					// Check if the animal already exists in the array
					for(int i = 0; i < animals.length; i++) {
						if(animals[i] != null && animals[i].getSort().equals(animalType)) {
							animalExists = true;
						}
					}
					
					// Push to animals array
					if(!animalExists) {
						Djur animalInstance = new Djur();
						animalInstance.setSort(animalType);
						animalInstance.setL�te(animalSound);
						
						animals[nextIndex] = animalInstance;
						nextIndex++;
					}
					
					// Reset index if needed
					if(nextIndex == 5) {
						nextIndex = 0;
					}
				
				  // Print out all animals
				} else {
					String message = "Djuren i djurparken:\n\n";
					
					for(int i = 0; i < animals.length; i++) {
						if(animals[i] != null) {
							message += "Djuret: " + animals[i].getSort() + " s�ger: " + animals[i].getL�te() + "\n";	
						}
					}
					
					showMessageDialog(null, message);
				}
				
			} catch (Exception e) {
				validInput = false;
				showMessageDialog(null, "N�gonting gick fel!");
			}
		}
	}
}
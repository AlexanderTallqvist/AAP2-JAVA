import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showOptionDialog;
import java.util.ArrayList;


import javax.swing.JFrame;

public class Uppg6Moment3 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		boolean animalExists;
		int userInput;
		ArrayList<Djur> animalArrayList = new ArrayList<Djur>();
		String[]animal;
		
		// Message box
		JFrame frame = new JFrame();
		String[] options = new String[2];
		options[0] = new String("L�gg till ett djur.");
		options[1] = new String("Visa alla djur.");

		while (validInput == true) {

			try {
				userInput = showOptionDialog(frame.getContentPane(), "Vad vill du g�ra?", "Djurparken", 0, INFORMATION_MESSAGE, null, options, null);
				
				// Add animal to the animals array list
				if(userInput == 0) {
					animalExists = false;
					animal = showInputDialog(null, "Ange djur och l�te i fromen: 'Djur, L�te'", "L�gg till djur", QUESTION_MESSAGE).toLowerCase().split(",");
					
					String animalType  = animal[0].trim();
					String animalSound = animal[1].trim();
					
					// Check if the animal already exists in the array list
					for(int i = 0; i < animalArrayList.size();  i++) {
						if(animalArrayList.get(i).getSort().equals(animalType)) {
							animalExists = true;
						}
					}
					
					// Push to animals array list
					if(!animalExists) {
						Djur animalInstance = new Djur();
						animalInstance.setSort(animalType);
						animalInstance.setL�te(animalSound);
						
						animalArrayList.add(animalInstance);
					}
					
				  // Print out all animals
				} else {
					String message = "Djuren i djurparken:\n\n";
					
					for(int i = 0; i < animalArrayList.size();  i++) {
						if(animalArrayList.get(i) != null) {
							message += "Djuret: " + animalArrayList.get(i).getSort() + " s�ger: " + animalArrayList.get(i).getL�te() + "\n";	
						}
					}
					
					showMessageDialog(null, message);
				}
				
			} catch (Exception e) {
				validInput = false;
				showMessageDialog(null, "N�gonting gick fel!");
			}
		}
	}
}
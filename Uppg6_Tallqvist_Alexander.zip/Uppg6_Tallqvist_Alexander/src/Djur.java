
public class Djur {

	private String Sort;
	private String L�te;
	
	public String getSort() {
		return Sort;
	}
	
	public void setSort(String sort) {
		Sort = sort;
	}
	
	public String getL�te() {
		return L�te;
	}
	
	public void setL�te(String l�te) {
		L�te = l�te;
	}
}

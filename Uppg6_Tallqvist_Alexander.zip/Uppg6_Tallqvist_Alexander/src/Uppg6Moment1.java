import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showOptionDialog;
import javax.swing.JFrame;

public class Uppg6Moment1 {
	
	public static void main(String[] args) {
		
		boolean validInput = true;
		boolean animalExists;
		int userInput, nextIndex = 0;
		String[][] animals = new String[5][2];
		String[]animal;
		
		// Message box
		JFrame frame = new JFrame();
		String[] options = new String[2];
		options[0] = new String("L�gg till ett djur.");
		options[1] = new String("Visa alla djur.");

		while (validInput == true) {

			try {
				userInput = showOptionDialog(frame.getContentPane(), "Vad vill du g�ra?", "Djurparken", 0, INFORMATION_MESSAGE, null, options, null);
				
				// Add animal to the animals array
				if(userInput == 0) {
					animalExists = false;
					animal = showInputDialog(null, "Ange djur och l�te i fromen: 'Djur, L�te'", "L�gg till djur", QUESTION_MESSAGE).toLowerCase().split(",");
					
					String animalType  = animal[0].trim();
					String animalSound = animal[1].trim();
					
					// Check if the animal already exists in the array
					for(int i = 0; i < animals.length; i++) {
						if(animals[i][0] != null && animals[i][0].equals(animalType)) {
							animalExists = true;
						}
					}
					
					// Push to animals array
					if(!animalExists) {
						animals[nextIndex][0] = animalType;
						animals[nextIndex][1] = animalSound;
						nextIndex++;
					}
					
					// Reset index if needed
					if(nextIndex == 5) {
						nextIndex = 0;
					}
				
				  // Print out all animals
				} else {
					String message = "Djuren i djurparken:\n\n";
					
					for(int i = 0; i < animals.length; i++) {
						if(animals[i][0] != null) {
							message += "Djuret: " + animals[i][0] + " s�ger: " + animals[i][1] + "\n";	
						}
					}
					
					showMessageDialog(null, message);
				}
				
			} catch (Exception e) {
				validInput = false;
				showMessageDialog(null, "N�gonting gick fel!");
			}
		}
	}
}
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Uppg4Moment2_a {

	public static void main(String[] args) {

		double katet1, katet2, hypotenusa = 0;
		boolean validInput = false;
		Uppg4Moment2_b Calculator = new Uppg4Moment2_b(); 

		while (validInput == false) {

			try {
				katet1 = Double.parseDouble(showInputDialog(null, "Ange triangels f�rsta katet.", "Katet 1", QUESTION_MESSAGE));
				katet2 = Double.parseDouble(showInputDialog(null, "Ange triangels andra katet.", "Katet 2", QUESTION_MESSAGE));
				hypotenusa = Calculator.calculateHypotenuse(katet1, katet2);
				
				if (hypotenusa != 0) {
					showMessageDialog(null, "Hypotenusan �r: " + String.format("%1.2f", hypotenusa) + " l�ngdenheter.");
					validInput = true;
				}
				
			} catch (Exception e) {
				showMessageDialog(null, "An error has occured.");
			}
		}
	}

}


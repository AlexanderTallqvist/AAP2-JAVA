import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;

public class Uppg4Moment3 {

	public static void main(String[] args) {
		int number = 0;
		number = Integer.parseInt(showInputDialog(null, "L�ngd p� Fibonacci serien:", "Fibonacci", QUESTION_MESSAGE));
		
	    for (int counter = 0; counter <= number; counter++) {
	        System.out.printf("Fibonacci av %d �r: %d\n", counter, fibonacci(counter));
	    }
	}

	public static int fibonacci(int number) {
		
		if ((number == 0) || (number == 1)) {
			return number;
		}
		
		return fibonacci(number - 1) + fibonacci(number - 2);
	}

}

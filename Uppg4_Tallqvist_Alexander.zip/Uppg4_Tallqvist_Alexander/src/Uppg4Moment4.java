import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;

public class Uppg4Moment4 {
	
	public static void main(String[] args) {
		
		int bas10 = 0;
		
		bas10 = Integer.parseInt(showInputDialog(null, "Ge ett tal i bas10:", "Till bas2", QUESTION_MESSAGE));
		System.out.println(convert(bas10));
	}
	
	
	public static String convert(int number) {
	    int kvot = number / 2;
	    int rest = number % 2;

	    if (kvot == 0) {
	        return Integer.toString(rest);      
	    }

	    return convert(kvot) + Integer.toString(rest);             
	}
}

import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.YES_NO_OPTION;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showConfirmDialog;
import java.util.Arrays;
import java.util.Random;

public class Uppg4Moment5 {
	
	public static void main(String[] args) {
		
		int guessAmount = 7;
		int wins = 0;
		int losses = 0;
		boolean wantsToPlay = true;
		String wordToGuess = getRandomWord();
		String underscores = generateUnderscores(wordToGuess);
		String oldUnderscores = underscores;
		String guessedLetter;

		while(wantsToPlay == true) {
			
			try {
				guessedLetter = showInputDialog(null, "Gissa p� en bokstav:", "Hangman", QUESTION_MESSAGE);
				underscores = takeTurn(guessedLetter, wordToGuess, underscores);
				
				if(!sameChars(underscores, oldUnderscores)) {
					oldUnderscores = underscores;
					showMessageDialog(null, "R�tt gissat! Du har " + guessAmount + " gissningar kvar.\n" + underscores);
				} else {
					guessAmount -= 1;
					showMessageDialog(null, "Fel gissat! Du har " + guessAmount + " gissningar kvar.\n" + underscores);
				}
				
				// We have won the round
				if(sameChars(wordToGuess, underscores)) {
					wins += 1;
					wantsToPlay = displayStatus(wins, losses, "Du har vunnit!", wordToGuess);
					
					if(wantsToPlay == true) {
						wordToGuess = getRandomWord();
						underscores = generateUnderscores(wordToGuess);
						oldUnderscores = underscores;
						guessAmount = 7;
					}
				}
				
				// We have lost the round
				if(guessAmount == 0) {
					losses += 1;
					wantsToPlay = displayStatus(wins, losses, "Du har f�rlorat!", wordToGuess);
					
					if(wantsToPlay == true) {
						wordToGuess = getRandomWord();
						underscores = generateUnderscores(wordToGuess);
						oldUnderscores = underscores;
						guessAmount = 7;
					}
				}	
			}
			
			catch(Exception e) {
				showMessageDialog(null, "N�gonting gick fel!");
			}
		}
	}
	
	// Generate a random word at the start of the game
	public static String getRandomWord() {
		
		String[] words = new String[] { "matbutik", "dator", "f�gelholk", "lampa", "tavla"};
		int rnd = new Random().nextInt(words.length);
		return words[rnd];
	}
	
	// Generate a string with underscores that matches the length of the random word
	public static String generateUnderscores(String randomWord) {
		
		String underscores = "";
		
		for (int i = 0; i < randomWord.length(); i++) {
			underscores += "_";
		}
		
		return underscores;
	}
	
	// Take a turn and check if the random words has the letter that was chosen
	public static String takeTurn(String guess, String wordToGuess, String undercores) {
		
		char[] undercoresChars = undercores.toCharArray();
		
		for (int i = -1; (i = wordToGuess.indexOf(guess, i + 1)) != -1; i++) {
			undercoresChars[i] = guess.charAt(0);
		}
		
		return String.valueOf(undercoresChars);
	}
	
	// Check if two strings have the same characters
	public static boolean sameChars(String firstStr, String secondStr) {
		
		  char[] first = firstStr.toCharArray();
		  char[] second = secondStr.toCharArray();
		  Arrays.sort(first);
		  Arrays.sort(second);
		  return Arrays.equals(first, second);
	}
	
	// Display a status message
	public static boolean displayStatus(int wins, int losses, String message, String wordToGuess) {
		showMessageDialog(null, message + " Ordet var: " + wordToGuess + ". \nHittills hard du vunnit: " + wins + "\nHittills hard du f�rlorat: " + losses);
		int dialogResult = showConfirmDialog (null, "Vill du spela p�nytt?","Spela p�nytt?", YES_NO_OPTION);
		
		if (dialogResult == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	
	
	
	
	
}

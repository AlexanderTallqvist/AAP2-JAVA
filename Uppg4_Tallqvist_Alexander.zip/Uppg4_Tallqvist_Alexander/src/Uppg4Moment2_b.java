
public class Uppg4Moment2_b {

	public double calculateHypotenuse(double katet1, double katet2) {
		
		return Math.sqrt(Math.pow(katet1, 2) + Math.pow(katet2, 2));
	}
	
}

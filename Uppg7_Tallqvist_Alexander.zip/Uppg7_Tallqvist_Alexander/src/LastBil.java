
public class LastBil extends Fordon {
	
	private String brand;
	private String model;
	
	public LastBil(String regNr, String owner, String model, String brand) {
		super(regNr, owner);
		this.brand = brand;
		this.model = model;
	}
	
    String getInfo() {
        String out = "Fordonets register nummer �r " + getRegNr() + " och den �gs av " + getOwner()
                   + "\nModellen �r " + getModel() + " och m�rket �r " + getBrand();
        return out;
    }

    protected String getBrand() {
		return brand;
	}

	protected void setBrand(String brand) {
		this.brand = brand;
	}

	protected String getModel() {
		return model;
	}

	protected void setModel(String model) {
		this.model = model;
	}
	
}

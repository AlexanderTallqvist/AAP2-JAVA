
public class PersonBil extends Fordon {
	
	private String brand;
	private String model;
	private int seats;
	
	public PersonBil(String regNr, String owner, String model, String brand, String seats) {
		super(regNr, owner);
		this.brand = brand;
		this.model = model;
		this.seats = Integer.parseInt(seats);
	}
	
    String getInfo() {
        String out = "Fordonets register nummer �r " + getRegNr() + " och den �gs av " + getOwner()
                   + "\nModellen �r " + getModel() + " och m�rket �r " + getBrand()
                   + "\nFordonet har " + getSeats() + " s�ten";
        return out;
    }

	protected String getBrand() {
		return brand;
	}

	protected void setBrand(String brand) {
		this.brand = brand;
	}

	protected String getModel() {
		return model;
	}

	protected void setModel(String model) {
		this.model = model;
	}

	protected int getSeats() {
		return seats;
	}

	protected void setSeats(int seats) {
		this.seats = seats;
	}
}

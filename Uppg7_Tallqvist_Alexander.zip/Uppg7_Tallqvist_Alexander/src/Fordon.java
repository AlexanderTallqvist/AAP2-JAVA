
public class Fordon extends AbstractFordon {

	private String regNr;
	private String owner;
	
	public Fordon(String regNr, String owner) {
		this.regNr = regNr;
		this.owner = owner;
	}

	protected String getRegNr() {
		return regNr;
	}
	
	protected void setRegNr(String regNr) {
		this.regNr = regNr;
	}
	
	protected String getOwner() {
		return owner;
	}
	
	protected void setOwner(String owner) {
		this.owner = owner;
	}
}

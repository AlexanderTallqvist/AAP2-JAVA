import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.DEFAULT_OPTION;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showOptionDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.util.ArrayList;

// Alla moment utf�rda
public class Uppg7Moment5 {

	public static void main(String[] args) {
		
		ArrayList<Fordon> allVehicles = new ArrayList<Fordon>();
		int userInput;
		boolean keepRunning = true;
		String[] buttons = { "L�gg till ett fordon", "Visa alla fordon", "St�ng programmet"};  
		
		while (keepRunning == true) {

			try {
				userInput = showOptionDialog(null, "Vad vill du g�ra?", "Fordon", DEFAULT_OPTION, QUESTION_MESSAGE, null, buttons, buttons[0]);
				
				if(userInput == 0) {
					String inputString = showInputDialog(null, "Ange ett nyt fordon i enligt f�ljande instruktioner:\n\n"
									   + "Vanligt fordon: 'abc-123, Kalle Karlsson'\n\n"
									   + "Lastbil: 'abc-123, Kalle Karlsson, Modell, M�rke'\n\n"
									   + "Personbil: 'abc-123, Kalle Karlsson, Modell, M�rke, Antal s�ten'\n\n"
									   + "Lastbil med egenskaper: 'abc-123, Kalle Karlsson, Modell, M�rke, Ombord, Volym, Fr�n, Till'\n\n",
									   "L�gg till ett fordon", QUESTION_MESSAGE);
					
					allVehicles = registerVehicles(inputString, allVehicles);
				}
				
				else if(userInput == 1) {
					displayAllVehicles(allVehicles);
				}
				
				else if(userInput == 2) {
					throw new Exception("Du har st�ngt programmet.");
				}			
				
				else {
					throw new Exception();
				}
				
			} 
			
			catch (ArrayIndexOutOfBoundsException e) {
				showMessageDialog(null, "Kontrolera antalen parametrar.");
			}
			
			catch (NumberFormatException e) {
				showMessageDialog(null, "Volym och s�ten m�ste anges som siffror.");
			}
			
			catch (Exception e) {
				keepRunning = false;
				String message = e.getMessage();
				showMessageDialog(null, message);
			}
			
		}

	}
	
	// Method for adding a new vehicle to the registered vehicles array list
	public static ArrayList<Fordon> registerVehicles(String registrationString, ArrayList<Fordon> allVehicles) {
		String[]vehInf = registrationString.split(",");
		
		if(vehInf.length == 2) {
			Fordon newVehicle = new Fordon(vehInf[0], vehInf[1]);
			allVehicles.add(newVehicle);
		}
		
		else if (vehInf.length == 4) {
			LastBil newVehicle = new LastBil(vehInf[0], vehInf[1], vehInf[2], vehInf[3]);
			allVehicles.add(newVehicle);
		}
		
		else if (vehInf.length == 5) {
			PersonBil newVehicle = new PersonBil(vehInf[0], vehInf[1], vehInf[2], vehInf[3], vehInf[4]);
			allVehicles.add(newVehicle);
		}
		
		else {
			LastBilEgenskaper newVehicle = new LastBilEgenskaper(vehInf[0], vehInf[1], vehInf[2],
										   vehInf[3], vehInf[4], vehInf[5], vehInf[6], vehInf[7]);
			allVehicles.add(newVehicle);
		}
		
		return allVehicles;
	}
	
	// Method for displaying all the vehicles in the registered vehicles array list
	public static void displayAllVehicles(ArrayList<Fordon> allVehicles) {
		String message = "ALLA REGISTRERADE FORDON\n \n";
		
		for (int i = 0; i < allVehicles.size(); i++) {
			message += allVehicles.get(i).getInfo() + "\n\n";
		}
		
		showMessageDialog(null, message);
	}
	
}

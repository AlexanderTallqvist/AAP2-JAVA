
public interface InterfaceLastBil {
    String getRoute();
}
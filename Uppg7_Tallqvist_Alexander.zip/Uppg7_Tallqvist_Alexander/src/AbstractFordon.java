
public abstract class AbstractFordon {
    
    String getInfo() {
        String out = "Fordonets register nummer �r " + getRegNr() + " och den �gs av " + getOwner();
        return out;
    }
    
    protected abstract String getRegNr();
    
    protected abstract String getOwner();
}

public class LastBilEgenskaper extends LastBil implements InterfaceLastBil {
	
	private String loadedWith;
	private double capacity;
	private String depart;
	private String destination;

	public LastBilEgenskaper(String regNr, String owner, String model, String brand, String loadedWith, String capacity, String depart, String destination) {
		super(regNr, owner, model, brand);
		this.loadedWith = loadedWith;
		this.capacity = Double.parseDouble(capacity);
		this.depart = depart;
		this.destination = destination;
		
	}
	
    String getInfo() {
        String out = "Fordonets register nummer �r " + getRegNr() + " och den �gs av " + getOwner()
                   + "\nModellen �r " + getModel() + " och m�rket �r " + getBrand()
                   + "\nFordonet �r lastat med " + getLoadedWith() + " och har en kapasitet p� " + getCapacity()
                   + getRoute();
        return out;
    }
	
	public String getRoute() {
		return "\nFordonet �r p�v�g fr�n " + getDepart() + " till " + getDestination();
	}

	protected String getLoadedWith() {
		return loadedWith;
	}

	protected void setLoadedWith(String loadedWith) {
		this.loadedWith = loadedWith;
	}

	protected double getCapacity() {
		return capacity;
	}

	protected void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	protected String getDepart() {
		return depart;
	}

	protected void setDepart(String depar) {
		this.depart = depar;
	}

	protected String getDestination() {
		return destination;
	}

	protected void setDestination(String destination) {
		this.destination = destination;
	}

}
